<#
Disclaimer:
This sample script is not supported under any Microsoft standard support program or service.
The sample script is provided AS IS without warranty of any kind. Microsoft further disclaims
all implied warranties including, without limitation, any implied warranties of merchantability
or of fitness for a particular purpose. The entire risk arising out of the use or performance of
the sample scripts and documentation remains with you. In no event shall Microsoft, its authors,
or anyone else involved in the creation, production, or delivery of the scripts be liable for any
damages whatsoever (including, without limitation, damages for loss of business profits, business
interruption, loss of business information, or other pecuniary loss) arising out of the use of or
inability to use the sample scripts or documentation, even if Microsoft has been advised of the
possibility of such damages
#>
<#
.Synopsis
    This script update the Exchange Configuration for Exchange Security Insight Collector script.
.DESCRIPTION
    This script can check online update and will update current version used with latest version

.EXAMPLE
.INPUTS
    .\Updater.ps1
        
.OUTPUTS
    No Output
.NOTES
    Developed by ksangui@microsoft.com and Nicolas Lepagnez
    Version : 1.0 - Released : Not Released - nilepagn
        - Adding TLS1.2 capability
        - Adding proxy capability
        - Adding support for offline update
        - Adding support for configuration file update
        - Adding support for AddOns update
        - Adding support for Beta version
        - Adding support for Force update
        - Adding support for Categories

        - Missing Documentation

#>

Param (
    [String] $JSONFileCondiguration = ".\Config\UpdaterConfig.json",
    
    $SpecificTargetVersion = $null,
    
    [string[]] $Categories = @("IIS-IoCs","OnlineMessageTracking"),

    [switch] $IsOutsideAzureAutomation,

    [bool] $WhatIf = $false,

    [bool] $VersionRollback = $false
)

$Global:isRunbook = if (-not $IsOutsideAzureAutomation) 
{
    if (!($null -eq (Get-Command "Get-AutomationVariable" -ErrorAction SilentlyContinue)))
    {
        if ($null -eq (Get-Module -Name Orchestrator* -ErrorAction SilentlyContinue))
        {
            $false
        }
        else {$true}
    }
    else {$false}
} else {$false}

$InformationPreference = "Continue"
$script:SupportedConfigurationVersion = "1.0"

$DateSuffixForFile = Get-Date -Format "yyyy-MM-dd-HH-mm-ss"
$ClearFilesOlderThan = 7
$Script:ConfigurationTargetVersion = $null
$Script:ConfigurationTargetVersionLoaded = $false

$Script:ConfigFiles = @("CollectExchSecConfiguration.json", "UpdaterConfig.json")
if ($Global:isRunbook) { $Script:FileListToCopy = @("Updater.ps1", "CollectExchSecIns.ps1", "CollectExchSecConfiguration.json", "UpdaterConfig.json") }   
else { $Script:FileListToCopy = @("Updater.ps1", "CollectExchSecIns.ps1", "CollectExchSecConfiguration.json", "UpdaterConfig.json", "setup.ps1") }

$Script:EndMessage = @()
$Script:EndMessageLevel = "Info"

Add-Type -AssemblyName System.IO.Compression

function Write-LogMessage {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [string]
        $Message,
        [Parameter(Mandatory=$false)]
        [string]
        $Category="General",
        [Parameter(Mandatory=$false)]
        [ValidateSet("Info","Warning","Error","Verbose")]
        [string]
        $Level="Info",
        [switch] $NoOutput
    )
    $line = "$(Get-Date -f 'yyyy/MM/dd HH:mm:ss')`t$Level`t$Category`t$Message"
    Set-Variable -Name UDSLogs  -Value "$UDSLogs`n$line" -Scope Script
    if($NoOutput -or $Global:DeactivateWriteOutput){
        Write-Host $line
        if ($script:FASTVerboseLevel) { Write-Verbose $line }
    }else{
        Write-Output $line
    }
    switch ($Level) {
        "Verbose" {
            if ($script:FASTVerboseLevel) { Write-Verbose "[VERBOSE] $Category :`t$Message" }
        }
        "Info" {
            Write-Information "[INFO] $Category :`t$Message"
        }
        "Warning" {
            Write-Warning "$Category :`t$Message"
        }
        "Error" {
            Write-Error "$Category :`t$Message"
        }
        Default {}
    }    
}

function CleanFiles
{
    Param(
        $ClearFilesOlderThan = 7,
        $ScriptLogPath,
        $outputpath = $null
    )

    $DirectoryList = @()
    $DirectoryList += $ScriptLogPath
    if (-not [string]::IsNullOrEmpty($outputpath)) { $DirectoryList += (Split-Path $outputpath) }

    Write-LogMessage "`t ..Cleaning Report and log files older than $ClearFilesOlderThan days."
    $MaxDate = (Get-Date).AddDays($ClearFilesOlderThan*-1)

    $OtherOldFiles = @()
    $FileList = @()
    if ($DirectoryList.count -gt 0)
    {
        foreach ($dir in $DirectoryList)
        {
            if (Test-Path $dir)
            {
                $OtherPathObj = Get-Item -Path $dir
                $OtherFiles = $OtherPathObj.GetFiles()
                $OtherOldFiles = $OtherFiles | Where-Object {$_.LastWriteTime -le $MaxDate}
                Write-LogMessage ("`t`t There is "+ $OtherFiles.Count + " existing files in $dir with "+ $OtherOldFiles.Count +" files older than $MaxDate.")
            }
            elseif (Test-Path ($scriptFolder + "\" + $dir))
            {
                $OtherPathObj = Get-Item -Path $dir
                $OtherFiles = $OtherPathObj.GetFiles()
                $OtherOldFiles = $OtherFiles | Where-Object {$_.LastWriteTime -le $MaxDate}
                Write-LogMessage ("`t`t There is "+ $OtherFiles.Count + " existing files in $dir with "+ $OtherOldFiles.Count +" files older than $MaxDate.")
            }
            $FileList += $OtherOldFiles
        }
    }

    $NbRemove = 0
    foreach ($File in $FileList)
    {
        if (-not $WhatIf) { Remove-Item $File.FullName -Confirm:$false }
        $NbRemove += 1
        Write-LogMessage ("`t`t`t File "+ $File.Name + " Removed.")
    }
    
    Write-LogMessage ("`t`t $NbRemove Files Removed for cleaning process.")
}

function Set-ESIContent{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true, ValueFromPipeline=$true) ]
        [string]
        $Content,
        [Parameter(Mandatory=$true)]
        [string]
        $Path
    )

    #Filename in the path
    $FileName = $Path.Split("\")[-1]

    if ($Script:AdvancedFilesToIgnore -contains $FileName) { Write-LogMessage "File $FileName is in the ignore list. It will not be updated." -Level Warning; return }

    Write-LogMessage "Write content to $Path"
    if ($PSVersionTable.PSVersion.Major -ge 7)
    {
        # PowerShell 7 and higher
        $Content | Set-Content -Path $Path -NoNewline -Encoding utf8NoBOM
    }
    else
    {
        # Powershell 5.1
        $Utf8NoBomEncoding = New-Object System.Text.UTF8Encoding $False
        #[System.IO.File]::WriteAllLines($Path, $Content, $Utf8NoBomEncoding) Prefer WriteAllText as it doesn't add newline at the end of the file
        [System.IO.File]::WriteAllText($Path, $Content, $Utf8NoBomEncoding)
    }
}

function LoadConfiguration 
{
    Param (
        $configurationFile,
        [switch] $VariableFromAzureAutomation
    )

    try
    {
        if ($VariableFromAzureAutomation)
        {
            $jsonConfig = Get-AutomationVariable -Name "UpdaterConfiguration" -ErrorAction Stop
            $jsonConfig = $jsonConfig | ConvertFrom-Json
        }
        else {
            $jsonConfig = Get-Content $configurationFile | ConvertFrom-Json
        }

        #Verify that the version of configuration file is greater than supported version
        if ($jsonConfig.SolutionMetadata.JSonVersion -lt $script:SupportedConfigurationVersion)
        {
            Write-LogMessage -Message "Configuration file version $($jsonConfig.SolutionMetadata.JSonVersion) is outdated. Features could not work correctly. Supported version is $($script:SupportedConfigurationVersion)" -Level Warning
        }

        if ($Global:IsRunbook)
        {
            if (-not [string]::IsNullOrEmpty($jsonConfig.Global.AutomationConfiguration)) 
            {   
                $Script:AutomationConfiguration = New-Object PSObject
                $Script:AutomationConfiguration | Add-Member -MemberType NoteProperty -Name "SubscriptionId" -Value $jsonConfig.Global.AutomationConfiguration.SubscriptionId
                $Script:AutomationConfiguration | Add-Member -MemberType NoteProperty -Name "ResourceGroup" -Value $jsonConfig.Global.AutomationConfiguration.ResourceGroup
                $Script:AutomationConfiguration | Add-Member -MemberType NoteProperty -Name "AutomationAccountName" -Value $jsonConfig.Global.AutomationConfiguration.AutomationAccountName
                $Script:AutomationConfiguration | Add-Member -MemberType NoteProperty -Name "RunbookName" -Value $jsonConfig.Global.AutomationConfiguration.RunbookName
            }
            else { Throw "Automation Configuration mandatory for updating a Runbook" }
        }
        else {
            if (-not [string]::IsNullOrEmpty($jsonConfig.Global.ServerConfiguration)) 
            {   
                $Script:ServerConfiguration = New-Object PSObject
                $Script:ServerConfiguration | Add-Member -MemberType NoteProperty -Name "LocalTargetPath" -Value $jsonConfig.Global.ServerConfiguration.LocalTargetPath
                
                if ($Script:ServerConfiguration.LocalTargetPath -eq "#DEFAULT#") 
                { 
                    $Script:ServerConfiguration.LocalTargetPath = $Script:scriptFolder 
                }

            }
            else { Throw "Target Path is mandatory for updating a script" }
        }

        
        if (-not [string]::IsNullOrEmpty($jsonConfig.Global.BackupActivated)) 
        {   
            $Script:BackupActivated = [Convert]::ToBoolean($jsonConfig.Global.BackupActivated)

            if ($null -ne $jsonConfig.Global.BackupConfiguration)
            {
                $Script:BackupConfiguration = @()

                foreach ($Entry in $jsonConfig.Global.BackupConfiguration)
                {
                    $EntryActive = [Convert]::ToBoolean($Entry.Active)
                    
                    if ($EntryActive -eq $false) 
                    { 
                        Write-LogMessage -Message "Backup Entry is not activated for Entry Type $($Entry.BackupType)" -Level Warning
                        continue 
                    }

                    $BkpConfigEntry = New-Object PSObject
                    $BkpConfigEntry | Add-Member -MemberType NoteProperty -Name "BackupType" -Value $Entry.BackupType

                    switch ($Entry.BackupType) {
                        "Local" 
                        {  
                            if (-not [string]::IsNullOrEmpty($Entry.LocalPath)) 
                            { 
                                $BkpConfigEntry | Add-Member -MemberType NoteProperty -Name "LocalPath" -Value $Entry.LocalPath
                                if ($BkpConfigEntry.LocalPath -eq "#DEFAULT#") { $BkpConfigEntry.LocalPath = $Script:ServerConfiguration.LocalTargetPath + "\Updater-AutoBackup" }
                            }
                            else { Throw "Backup Path is mandatory for local type. #DEFAULT# value can be used." }
                        }
                        "AzureBlob"
                        {
                            if (-not [string]::IsNullOrEmpty($Entry.StorageAccountName) -and -not [string]::IsNullOrEmpty($Entry.StorageContainerName)) 
                            { 
                                $BkpConfigEntry | Add-Member -MemberType NoteProperty -Name "StorageAccountName" -Value $Entry.StorageAccountName
                                $BkpConfigEntry | Add-Member -MemberType NoteProperty -Name "StorageContainerName" -Value $Entry.StorageContainerName
                            }
                            else { Throw "Storage Account and Container Name are mandatory for Azure Storage type" }
                        }
                        Default {
                            Throw "Backup Type $($Entry.BackupType) is not supported"
                        }

                    }

                    if (-not [string]::IsNullOrEmpty($Entry.RetentionPeriod))
                    {
                        $BkpConfigEntry | Add-Member -MemberType NoteProperty -Name "RetentionPeriod" -Value ([Convert]::ToInt32($Entry.RetentionPeriod))
                    }
                    else { $BkpConfigEntry | Add-Member -MemberType NoteProperty -Name "RetentionPeriod" -Value 7 }

                    $Script:BackupConfiguration += $BkpConfigEntry
                }

            }
            else {
                Throw "Backup Configuration is mandatory when BackupActivated is activated"
            }
        }
        else { $Script:BackupActivated = $false }
            
        if (-not [string]::IsNullOrEmpty($jsonConfig.Advanced.Beta)) 
        {   
            $Script:BetaVersion = [Convert]::ToBoolean($jsonConfig.Advanced.Beta)
        }
        else { $Script:BetaVersion = $false }

        if (-not [String]::IsNullOrEmpty($jsonConfig.Advanced.Useproxy)) {
            $script:Useproxy = [Convert]::ToBoolean($jsonConfig.Advanced.Useproxy)
            if ($script:Useproxy) { 
                if (-not [string]::IsNullOrEmpty($jsonConfig.Advanced.ProxyUrl)) {$script:ProxyUrl = $jsonConfig.Advanced.ProxyUrl} 
                else { Throw "URL Proxy is needed when UseProxy is activated"}
            }
        } 
        else {
            $script:Useproxy = $false
        }

        if (-not [string]::IsNullOrEmpty($jsonConfig.Advanced.ForceUpdateResetFiles)) 
        {   
            $Script:ForceUpdate = [Convert]::ToBoolean($jsonConfig.Advanced.ForceUpdateResetFiles)
        }
        else { $Script:ForceUpdate = $false }

        if ($null -ne $jsonConfig.Advanced.IgnoreFiles) 
        {   
            $Script:AdvancedFilesToIgnore = $jsonConfig.Advanced.IgnoreFiles
        }
        else { $Script:AdvancedFilesToIgnore = @() }


        if (-not [string]::IsNullOrEmpty($jsonConfig.UpdateTypeConfiguration)) 
        {   
            $Script:UpdateTypeConfiguration = New-Object PSObject
            $Script:UpdateTypeConfiguration | Add-Member -MemberType NoteProperty -Name "UpdateType" -Value $jsonConfig.UpdateTypeConfiguration.UpdateType.UpdateTypeValue

            if($Script:UpdateTypeConfiguration.UpdateType -notin @("Full", "ScriptOnly","ConfigOnly","AddOnsOnly","Partial")) { Throw "Update Type $($Script:UpdateTypeConfiguration.UpdateType) is not supported" }

            if ($Script:UpdateTypeConfiguration.UpdateType -eq "Partial") 
            {
                $Script:UpdateTypeConfiguration | Add-Member -MemberType NoteProperty -Name "PartialUpdateType" -Value $jsonConfig.UpdateTypeConfiguration.UpdateTypePartial.PartialUpdateTypeValue
                foreach ($PartialType in $Script:UpdateTypeConfiguration.PartialUpdateType)
                {
                    if ($PartialType -notin @("Script","AddOns","Config","CompareConfig")) { Throw "Partial Update Type $PartialType is not supported" }
                    if ($Global:IsRunbook -and $PartialType -eq "AddOns") { Throw "AddOns Partial Update Type is not supported in Runbook mode" }
                }
            }
            else { 
                
                if ($Global:IsRunbook -and $Script:UpdateTypeConfiguration.UpdateType -eq "AddOnsOnly") { Throw "AddOnsOnly Update Type is not supported in Runbook mode" }
                $Script:UpdateTypeConfiguration | Add-Member -MemberType NoteProperty -Name "PartialUpdateType" -Value $null 
            }

            $Script:UpdateTypeConfiguration | Add-Member -MemberType NoteProperty -Name "UpdateSourceType" -Value $jsonConfig.UpdateTypeConfiguration.UpdateSourceType.UpdateSourceValue

            switch ($Script:UpdateTypeConfiguration.UpdateSourceType)
            {
                "Local"
                {
                    if ($Global:IsRunbook) { Throw "Local Source Path is not supported in Runbook mode" }
                    
                    if (-not [string]::IsNullOrEmpty($jsonConfig.UpdateTypeConfiguration.UpdateSourceType.UpdateSourceTypeLocalPath) -and $jsonConfig.UpdateTypeConfiguration.UpdateSourceType.UpdateSourceTypeLocalPath -ne "#SourceWithFilesForLocalUpdate#") 
                    {   
                        if (Test-Path $jsonConfig.UpdateTypeConfiguration.UpdateSourceType.UpdateSourceTypeLocalPath) 
                        {
                            $Script:UpdateTypeConfiguration | Add-Member -MemberType NoteProperty -Name "UpdateSourceTypeLocalPath" -Value $jsonConfig.UpdateTypeConfiguration.UpdateSourceType.UpdateSourceTypeLocalPath
                        }
                        else { Throw "Local Source Path $($jsonConfig.UpdateTypeConfiguration.UpdateSourceType.UpdateSourceTypeLocalPath) does not exist" }
                    }
                    else { Throw "Local Source Path is mandatory" }
                }
                "Internet"
                {
                    $Script:UpdateTypeConfiguration | Add-Member -MemberType NoteProperty -Name "UpdateSourceTypeLocalPath" -Value $null
                    $Script:FromInternet = $true
                }
                Default {
                    Throw "Update Source Type $($Script:UpdateTypeConfiguration.UpdateSourceType) is not supported"
                }
            }

            $Script:UpdateTypeConfiguration | Add-Member -MemberType NoteProperty -Name "UpdateTargetType" -Value $jsonConfig.UpdateTypeConfiguration.UpdateTargetType.UpdateTargetValue

            switch ($Script:UpdateTypeConfiguration.UpdateTargetType)
            {
                "Download"
                {
                    if ($Script:UpdateTypeConfiguration.UpdateSourceType -eq "Local") { Throw "Download Update Target Type is not supported with Local Source Type" }
                    
                    if (-not [string]::IsNullOrEmpty($jsonConfig.UpdateTypeConfiguration.UpdateTargetType.UpdateTargetTypeLocalPath) -and $jsonConfig.UpdateTypeConfiguration.UpdateTargetType.UpdateTargetTypeLocalPath -ne "#TargetToStoreDownloadedFiles#") 
                    {   
                        if (Test-Path $jsonConfig.UpdateTypeConfiguration.UpdateTargetType.UpdateTargetTypeLocalPath) 
                        {
                            $Script:UpdateTypeConfiguration | Add-Member -MemberType NoteProperty -Name "UpdateTargetTypeLocalPath" -Value $jsonConfig.UpdateTypeConfiguration.UpdateTargetType.UpdateTargetTypeLocalPath
                        }
                        else { Throw "Local Target Path $($jsonConfig.UpdateTypeConfiguration.UpdateTargetType.UpdateTargetTypeLocalPath) does not exist" }
                    }
                    else { Throw "Local Target Path is mandatory" }
                }
                "Replace"
                {
                    $Script:UpdateTypeConfiguration | Add-Member -MemberType NoteProperty -Name "UpdateTargetTypeLocalPath" -Value $null
                }
                Default {
                    Throw "Update Target Type $($Script:UpdateTypeConfiguration.UpdateTargetType) is not supported"
                }
            }
            
        }
        else { Throw "Update Type Configuration is mandatory" }
        
    }
    catch
    {
        Write-LogMessage -Message "Impossible to process configuration - Exception: $($_.Exception.Message) `n StackTrace: $($_.ScriptStackTrace) `n PositionMessage: $($_.InvocationInfo.PositionMessage)" -Level Error
        throw $_
    }
}

function Start-ScriptBackup
{
    Param (
        $ClearFilesOlderThan = 7
    )

    Write-LogMessage "`t ..Backup Activated"

    if ($Script:IsAlreadyBackup) { Write-LogMessage "`t ..Backup already done, no need to do it again"; return }

    foreach ($BckpEntry in $Script:BackupConfiguration)
    {
        try {            
            switch($BckpEntry.BackupType)
            {
                "Local" 
                {
                    if (!(Test-Path $BckpEntry.LocalPath) -and -not $WhatIf) {New-Item -Path $BckpEntry.LocalPath -ItemType Directory | Out-Null}

                    # remove all previous backup folders older than 7 days
                    $MaxDate = (Get-Date).AddDays($BckpEntry.RetentionPeriod * -1)
                    $BackupFolders = Get-ChildItem -Path $BckpEntry.LocalPath -Directory
                    $BackupFolders = $BackupFolders | Where-Object {$_.LastWriteTime -le $MaxDate}
                    foreach ($BackupFolder in $BackupFolders)
                    {
                        if (-not $WhatIf) { Remove-Item $BackupFolder.FullName -Recurse -Confirm:$false }
                        else { Write-LogMessage "`t ..Backup folder $BackupFolder removed."}
                    }

                    $CurrentBackupPath = $BckpEntry.LocalPath + "\Updater-" + (Get-Date -Format "yyyy-MM-dd_HH-mm-ss")
                    if (-not $WhatIf) { New-Item -Path $CurrentBackupPath -ItemType Directory | Out-Null }
                    Write-LogMessage "`t ..Backup folder created at $CurrentBackupPath"

                    # copy all files from the script folder to the backup folder
                    $ScriptFiles = Get-ChildItem -Path $ServerConfiguration.LocalTargetPath -File
                    foreach ($ScriptFile in $ScriptFiles)
                    {
                    if (-not $WhatIf) { Copy-Item -Path $ScriptFile.FullName -Destination $CurrentBackupPath }
                    else { Write-LogMessage "`t ..File $ScriptFile copied to backup folder." }
                    }
                    Write-LogMessage "`t ..Script files copied to backup folder."

                    # copy all files from the config folder in Targetpath to the backup folder including subfolders
                    $ConfigFiles = Get-ChildItem -Path "$($Script:ServerConfiguration.LocalTargetPath)\Config" -Recurse -Include "*.json"
                    $ConfigFiles += Get-ChildItem -Path "$($Script:ServerConfiguration.LocalTargetPath)" -Include "*.json"
                    foreach ($ConfigFile in $ConfigFiles)
                    {
                        $ConfigFileDestination = $CurrentBackupPath + $ConfigFile.FullName.Substring($Script:ServerConfiguration.LocalTargetPath.Length)
                        # if the destination directory does not exist, create it
                        if (!(Test-Path (Split-Path $ConfigFileDestination))) 
                        {
                            if (-not $WhatIf) { New-Item -Path (Split-Path $ConfigFileDestination) -ItemType Directory | Out-Null }
                            else { Write-LogMessage "`t ..Folder $(Split-Path $ConfigFileDestination) created." }
                        }
                        if (-not $WhatIf) { Copy-Item -Path $ConfigFile.FullName -Destination $ConfigFileDestination }
                        else { Write-LogMessage "`t ..File $ConfigFile copied to backup folder." }
                    }
                }
                "AzureBlob"
                {
                    if (-not (Get-Module -Name Az.Storage -ListAvailable))
                    {
                        Write-LogMessage "`nAzure Storage Account module not available" -Level Error
                        throw "Azure Storage Account module not available"
                    }
                    elseif (-not (Get-Command -Name Connect-AzAccount -Module Az.Accounts -ErrorAction SilentlyContinue))
                    {
                        Write-LogMessage "Azure Storage Account module not available" -Level Error
                        throw "Azure Storage Account module not available"
                    }

                    $ResultAccount = Connect-AzAccount -Identity -Tenant $ProcessorEntry.TenantID
                    if ($null -eq $ResultAccount)
                    {
                        Throw "Impossible to authenticate to Azure Storage Account"
                    }
                    else {
                        Write-LogMessage "Azure Storage Account processor authenticated"
                    }

                    # BEGIN: Create a new blob client
                    $context = New-AzStorageContext -StorageAccountName $BckpEntry.StorageAccountName -UseConnectedAccount
                    # END: Create a new blob client

                    # BEGIN: Create a new container if it doesn't exist
                    $container = Get-AzStorageContainer -Context $context -Name $BckpEntry.StorageContainerName
                    if ($null -eq $container) {
                        $container = New-AzStorageContainer -Name $BckpEntry.StorageContainerName -Context $context
                    }
                    # END: Create a new container if it doesn't exist
                    
                    
                    # remove all previous backup folders older than 7 days
                    $MaxDate = (Get-Date).AddDays($BckpEntry.RetentionPeriod * -1)
                    $Blobs = Get-AzStorageBlob -Prefix "Updater-" -Container $container.Name -Context $context `
                        | Where-Object{$_.LastModified.DateTime -le $MaxDate}
                    foreach ($Blob in $Blobs)
                    {
                        if (-not $WhatIf) { Remove-AzStorageBlob -Blob $Blob.Name -Container $container.Name -Context $context }
                        else { Write-LogMessage "`t ..Backup folder $Blob removed."}
                    }

                    $FolderBasePath = "Updater-" + (Get-Date -Format "yyyy-MM-dd_HH-mm-ss")
                    Write-LogMessage "`t ..Backup virtual folder will be $FolderBasePath"

                    # copy all files from the script folder to the backup folder
                    $ScriptFiles = Get-ChildItem -Path $ServerConfiguration.LocalTargetPath -File
                    foreach ($ScriptFile in $ScriptFiles)
                    {
                        if (-not $WhatIf) 
                        { 
                            Set-AzStorageBlobContent -File $ScriptFile.FullName -Container $container.Name -Blob "$FolderBasePath\$($ScriptFile.Name)" -Context $context
                        }
                        else { Write-LogMessage "`t ..File $ScriptFile copied to backup folder." }
                    }
                    Write-LogMessage "`t ..Script files copied to backup folder."

                    # copy all files from the config folder in Targetpath to the backup folder including subfolders
                    $ConfigFiles = Get-ChildItem -Path "$($Script:ServerConfiguration.LocalTargetPath)\Config" -Recurse -Include "*.json"
                    $ConfigFiles += Get-ChildItem -Path "$($Script:ServerConfiguration.LocalTargetPath)" -Include "*.json"
                    foreach ($ConfigFile in $ConfigFiles)
                    {
                        $ConfigFileDestination = $ConfigFile.FullName.Substring($Script:ServerConfiguration.LocalTargetPath.Length + 1)
                        $BlobName = "$FolderBasePath\$ConfigFileDestination"
                        if (-not $WhatIf) 
                        { 
                            Set-AzStorageBlobContent -File $ConfigFile.FullName -Container $container.Name -Blob $BlobName -Context $context
                        }
                        else { Write-LogMessage "`t ..File $ConfigFile copied to backup folder." }
                    }
                }
                Default {
                    Throw "Backup Type $($BckpEntry.BackupType) is not supported"
                }
            }
        }
        catch
        {
            Write-LogMessage -Message "Impossible to process backup - Exception: $($_.Exception.Message) `n StackTrace: $($_.ScriptStackTrace) `n PositionMessage: $($_.InvocationInfo.PositionMessage)" -Level Error
        }
    }
    $Script:IsAlreadyBackup = $true
}

function Get-UDSLogs
{
    [CmdletBinding()]
    param()

    return $Script:UDSLogs
}

function CheckRecursive
{
    Param(
        $JsonSegment,
        $JsonTestSegment,
        $TestType,
        $Path = "Root",
        [switch] $ApplyUpdate
    )

    $memberlist = $JsonSegment | Get-Member -MemberType NoteProperty

    $ReturnObject = New-Object -TypeName PSObject
    $ReturnObject | Add-Member -MemberType NoteProperty -Name "Path" -Value $Path
    $ReturnObject | Add-Member -MemberType NoteProperty -Name "ErrorSubList" -Value @()
    $ReturnObject | Add-Member -MemberType NoteProperty -Name "ErrorInPath" -Value @()
    $ReturnObject | Add-Member -MemberType NoteProperty -Name "ErrorCount" -Value 0
    $ReturnObject | Add-Member -MemberType NoteProperty -Name "TotalList" -Value @()
    foreach ($attribMember in $memberlist)
    {
        if ($attribMember.Name -in @("AuditFunctions", "VersionInformation", "AuditFunctionsFiles", "AuditFunctionProtectedArea", "InstanceExample")) {continue;}
    
        $errorTest = $false
        if ($null -eq $JsonTestSegment.($attribMember.Name))
        {
            Write-Host "`tEntry $Path\$($attribMember.Name) is missing in $TestType Version of configuration" -ForegroundColor Yellow
            $MissingEntry = New-Object -TypeName PSObject
            $MissingEntry | Add-Member -MemberType NoteProperty -Name "Path" -Value $Path
            $MissingEntry | Add-Member -MemberType NoteProperty -Name "Entry" -Value $attribMember.Name
            $MissingEntry | Add-Member -MemberType NoteProperty -Name "EntryValue" -Value $JsonSegment.($attribMember.Name)
            $MissingEntry | Add-Member -MemberType NoteProperty -Name "ErrorMessage" -Value "`tEntry $Path\$($attribMember.Name) is missing in $TestType Version of configuration"
            $ReturnObject.ErrorInPath += $MissingEntry
            $ReturnObject.TotalList += $MissingEntry
            $ReturnObject.ErrorCount += 1
            $errorTest = $true

            if ($ApplyUpdate) { $JsonTestSegment | Add-Member NoteProperty -Name $attribMember.Name -Value $JsonSegment.($attribMember.Name) }
        }
        else {
            Write-Host "`tEntry $Path\$($attribMember.Name) exists in $TestType Version of configuration"
        }
        $subResult = $JsonSegment.($attribMember.Name)
        $subTestResult = $JsonTestSegment.($attribMember.Name)

        if (-not $errorTest -and $null -ne $subResult -and $attribMember.Definition.StartsWith("System.Management.Automation.PSCustomObject"))
        {
            $ReturnObject.ErrorSubList = CheckRecursive -JsonSegment $subResult -JsonTestSegment $subTestResult -TestType $TestType -Path ($Path + "\$($attribMember.Name)") -ApplyUpdate:$ApplyUpdate
            $ReturnObject.ErrorCount += $ReturnObject.ErrorSubList.ErrorCount
            $ReturnObject.TotalList += $ReturnObject.ErrorSubList.TotalList
        }
    }

    return $ReturnObject
}

function Update-AddonsFromInternetRepository
{
    Param (
        [switch] $Beta,
        $TargetPath,
        $Category = $null  
    )

    if (-not $Global:isRunbook )
    {
        # Verify the cache directory exists
        $ScriptAddonCachePath = $TargetPath + '\Config\Add-Ons\'
        $GithubSourcePath = "https://raw.githubusercontent.com/nlepagnez/ESI-PublicContent/main/Operations/ESICollector-Addons"

        if ($Beta)
        {
            $GithubSourcePath += "/Beta"
        }

        if ($null -ne $Category)
        {
            $ScriptAddonCachePath += "Categories\$($Category)\"
            $GithubSourcePath += "/Categories/$($Category)/"
        }

        Push-Location ($TargetPath);
        if (! (Test-Path $ScriptAddonCachePath)) 
        { 
            Write-LogMessage -Message "Configuration directory doesn't exist, Critital error" -Level Error
            return $null
        }
        
        $files = Get-ChildItem -Path $ScriptAddonCachePath -Filter "ESICollector-*.json" 
        if ($null -eq $files -or $files.count -le 0) 
        {
            Write-LogMessage -Message "No config file found in Config directory, New configuration files will be downloaded" -Level Error
            $DownloadConfiguration = $True
        }

        if (Test-Path ($ScriptAddonCachePath + "ESIChecksumFiles.json"))
        {
            $ChecksumContent = Get-Content ($ScriptAddonCachePath + "ESIChecksumFiles.json") | ConvertFrom-Json
            if ($ChecksumContent.Files.Count -ne $files.count)
            {
                Write-LogMessage -Message "Invalidate confguration because incoherence in number of files - Theory : $($ChecksumContent.Files.Count) / Real : $($files.count)" -Level Warning; 

                $DownloadConfiguration = $True
            }
            else {
                foreach ($checksumfile in $ChecksumContent.Files)
                {
                    if ((Get-FileHash -Path ($ScriptAddonCachePath + $checksumfile.FileName) -Algorithm SHA256).Hash -ne $checksumfile.FileCheckSum)
                    {
                        Write-LogMessage -Message "Invalidate Configuration because cached file modified outside authorized method ($($checksumfile.FileName))" -Level Warning; 
                        $DownloadConfiguration = $True
                        break;
                    }
                }
            }
        }
        else {
            Write-LogMessage -Message "Invalidate Configuration because ESIChecksumFiles.json not present" -Level Warning; 
            $DownloadConfiguration = $True
        }

        # Retrieve File Checksum list
        
        try {
            if ($script:Useproxy)
            {
                $WebResult = invoke-WebRequest -Uri "$GithubSourcePath/ESIChecksumFiles.json" -UseBasicParsing -Proxy $Script:ProxyUrl
            }
            else
            {
                $WebResult = invoke-WebRequest -Uri "$GithubSourcePath/ESIChecksumFiles.json" -UseBasicParsing
            }
        }
        catch {
            Write-LogMessage -Message "Impossible to retrieve files from Online Github. Error : $($_.Exception)" -Level Warning; 
            return $null
        }
        
        if (-not $DownloadConfiguration) { $localHash = Get-FileHash -Path ($ScriptAddonCachePath + "ESIChecksumFiles.json") -Algorithm SHA256 }

        $stringAsStream = [System.IO.MemoryStream]::new()
        $writer = [System.IO.StreamWriter]::new($stringAsStream)
        $writer.write($WebResult.Content)
        $writer.Flush()
        $stringAsStream.Position = 0
        $onlineHash = Get-FileHash -InputStream $stringAsStream -Algorithm SHA256

        if (-not $DownloadConfiguration -and $localHash.Hash -ne $onlineHash.Hash)
        {
            Write-LogMessage -Message "New online content. Cache invalidation to update content"; 
            $DownloadConfiguration = $True
        }

        if ($DownloadConfiguration) 
        {
            Start-ScriptBackup

            if (-not $WhatIf) { Get-ChildItem -Path $ScriptAddonCachePath -File | Remove-Item -Confirm:$false }
            else { Write-LogMessage -Message "WhatIf mode, no file will be removed - Tested file : $ScriptAddonCachePath" }
           
            Write-LogMessage -Message "Update Cache Content"; 
            if (-not $WhatIf) { $WebResult.Content | Set-ESIContent -Path ($ScriptAddonCachePath + "ESIChecksumFiles.json")}
            else { Write-LogMessage -Message "WhatIf mode, no file will be created - Tested file : $ScriptAddonCachePath ESIChecksumFiles.json" }
            $OnlineFiles = $WebResult.Content | ConvertFrom-Json

            # Add all file in the list
            foreach ($OnlineFile in $OnlineFiles.Files)
            {
                $uri = "$GithubSourcePath/$($OnlineFile.FileName)"
                try {
                    if ($script:Useproxy)
                    {
                        $WebResult = invoke-WebRequest -Uri $uri -UseBasicParsing -Proxy $Script:ProxyUrl
                    }
                    else
                    {
                        $WebResult = invoke-WebRequest -Uri $uri -UseBasicParsing
                    }
                }
                catch {
                    Write-LogMessage -Message "Impossible to retrieve file $($OnlineFile.FileName) from Online Github. Error : $($_.Exception)" -Level Warning; 
                }
                if (-not $WhatIf) { $WebResult.Content | Set-ESIContent -Path ($ScriptAddonCachePath + $OnlineFile.FileName)}
                else { Write-LogMessage -Message "WhatIf mode, no file will be created - Tested file : $ScriptAddonCachePath$($OnlineFile.FileName)" }
            }
        }
        else {
            Write-LogMessage -Message "Configuration is up to date without any update needed"; 
        }
    }
    else {
        Write-LogMessage -Message "Runbook mode, no need to update configuration, directly downloaded from Github";
    }
}

function Start-AddonsDownload
{
    Param (
        [switch] $Beta,
        $TargetPath,
        $Category = $null
    )

    if (-not $Global:isRunbook )
    {
        # Verify the cache directory exists
        $ScriptAddonCachePath = $TargetPath + '\Config\Add-Ons\'
        $GithubSourcePath = "https://raw.githubusercontent.com/nlepagnez/ESI-PublicContent/main/Operations/ESICollector-Addons"

        if ($Beta)
        {
            $GithubSourcePath += "/Beta"
        }

        if ($null -ne $Category)
        {
            $ScriptAddonCachePath += "Categories\$($Category)\"
            $GithubSourcePath += "/Categories/$($Category)"
        }
        
        if (! (Test-Path $ScriptAddonCachePath)) 
        { 
            if (-not $WhatIf) { mkdir $ScriptAddonCachePath -Force | Out-Null }
            else { Write-LogMessage -Message "WhatIf mode, no directory will be created - Tested directory : $ScriptAddonCachePath" }
        }
                
        Write-LogMessage -Message "Update Cache Content"; 
        try {
            if ($script:Useproxy)
            {
                $WebResult = invoke-WebRequest -Uri "$GithubSourcePath/ESIChecksumFiles.json" -UseBasicParsing -Proxy $Script:ProxyUrl
            }
            else
            {
                $WebResult = invoke-WebRequest -Uri "$GithubSourcePath/ESIChecksumFiles.json" -UseBasicParsing
            }
        }
        catch {
            Write-LogMessage -Message "Impossible to retrieve files from Online Github. Error : $($_.Exception)" -NoOutput -Level Warning; 
            return $null
        }

        if (-not $WhatIf) { $WebResult.Content | Set-ESIContent -Path ($ScriptAddonCachePath + "ESIChecksumFiles.json") }
        else { Write-LogMessage -Message "WhatIf mode, no file will be created - Tested file : $ScriptAddonCachePath ESIChecksumFiles.json" }
        
        $OnlineFiles = $WebResult.Content | ConvertFrom-Json

        # Add all file in the list
        foreach ($OnlineFile in $OnlineFiles.Files)
        {
            $uri = "$GithubSourcePath/$($OnlineFile.FileName)"
            try {
                if ($script:Useproxy)
                {
                    $WebResult = invoke-WebRequest -Uri $uri -UseBasicParsing -Proxy $Script:ProxyUrl
                }
                else
                {
                    $WebResult = invoke-WebRequest -Uri $uri -UseBasicParsing
                }
            }
            catch {
                Write-LogMessage -Message "Impossible to retrieve file $($OnlineFile.FileName) from Online Github. Error : $($_.Exception)" -Level Warning; 
            }
            if (-not $WhatIf) { $WebResult.Content | Set-ESIContent -Path ($ScriptAddonCachePath + $OnlineFile.FileName) }
            else { Write-LogMessage -Message "WhatIf mode, no file will be created - Tested file : $ScriptAddonCachePath$($OnlineFile.FileName)" }
        }
    }
    else {
        Write-LogMessage -Message "Runbook mode, no need to update configuration, directly downloaded from Github";
    }
}

function Update-AddonsOfflineMode
{
    Param (
        [switch] $Beta,
        $SourcePath,
        $TargetPath,
        $Category = $null  
    )

    if (-not $Global:isRunbook )
    {
        # Verify the cache directory exists
        $ScriptAddonCachePath = $TargetPath + '\Config\Add-Ons\'
        $GithubSourcePath = $SourcePath + '\Config\Add-Ons\'

        if ($null -ne $Category)
        {
            $ScriptAddonCachePath += "Categories\$($Category)\"
            $GithubSourcePath += "\Categories\$($Category)"
        }

        Push-Location ($TargetPath);
        if (! (Test-Path $ScriptAddonCachePath)) 
        { 
            Write-LogMessage -Message "Configuration directory doesn't exist, Critital error" -Level Error
            return $null
        }
        
        $files = Get-ChildItem -Path $ScriptAddonCachePath -Filter "ESICollector-*.json" 
        if ($null -eq $files -or $files.count -le 0) 
        {
            Write-LogMessage -Message "No config file found in Config directory, New configuration files will be downloaded" -Level Error
            $DownloadConfiguration = $True
        }

        if (Test-Path ($ScriptAddonCachePath + "ESIChecksumFiles.json"))
        {
            $ChecksumContent = Get-Content ($ScriptAddonCachePath + "ESIChecksumFiles.json") | ConvertFrom-Json
            if ($ChecksumContent.Files.Count -ne $files.count)
            {
                Write-LogMessage -Message "Invalidate confguration because incoherence in number of files - Theory : $($ChecksumContent.Files.Count) / Real : $($files.count)" -Level Warning; 
                $DownloadConfiguration = $True
            }
            else {
                foreach ($checksumfile in $ChecksumContent.Files)
                {
                    if ((Get-FileHash -Path ($ScriptAddonCachePath + $checksumfile.FileName) -Algorithm SHA256).Hash -ne $checksumfile.FileCheckSum)
                    {
                        Write-LogMessage -Message "Invalidate Configuration because cached file modified outside authorized method ($($checksumfile.FileName))" -Level Warning; 
                        $DownloadConfiguration = $True
                        break;
                    }
                }
            }
        }
        else {
            Write-LogMessage -Message "Invalidate Configuration because ESIChecksumFiles.json not present" -Level Warning; 
            
            if (-not $WhatIf) { Get-ChildItem -Path $ScriptAddonCachePath | Remove-Item -Confirm:$false }
            else { Write-LogMessage -Message "WhatIf mode, no file will be removed - Tested file : $ScriptAddonCachePath" }
                
            $DownloadConfiguration = $True
        }

        # Retrieve File Checksum list
        
        try {
            $WebResult = Get-Content -Path ($GithubSourcePath + "\ESIChecksumFiles.json")
        }
        catch {
            Write-LogMessage -Message "Impossible to retrieve files from Online Github. Error : $($_.Exception)" -Level Warning; 
            return $null
        }
        
        $localHash = Get-FileHash -Path ($ScriptAddonCachePath + "ESIChecksumFiles.json") -Algorithm SHA256

        $stringAsStream = [System.IO.MemoryStream]::new()
        $writer = [System.IO.StreamWriter]::new($stringAsStream)
        $writer.write($WebResult)
        $writer.Flush()
        $stringAsStream.Position = 0
        $onlineHash = Get-FileHash -InputStream $stringAsStream -Algorithm SHA256

        if ($localHash.Hash -ne $onlineHash.Hash)
        {
            Write-LogMessage -Message "New online content. Cache invalidation to update content"; 
            $DownloadConfiguration = $True
        }

        if ($DownloadConfiguration) 
        {
            Start-ScriptBackup
            
            if (-not $WhatIf) { Get-ChildItem -Path $ScriptAddonCachePath -File | Remove-Item -Confirm:$false }
                else { Write-LogMessage -Message "WhatIf mode, no file will be removed - Tested file : $ScriptAddonCachePath" }
            
            Write-LogMessage -Message "Update Cache Content"; 
            $WebResult | Set-ESIContent -Path ($ScriptAddonCachePath + "ESIChecksumFiles.json")
            $OnlineFiles = $WebResult | ConvertFrom-Json

            # Add all file in the list
            foreach ($OnlineFile in $OnlineFiles.Files)
            {
                $uri = "$GithubSourcePath\$($OnlineFile.FileName)"
                try {
                    $WebResult = Get-Content -Path $uri -ErrorAction Stop
                }
                catch {
                    Write-LogMessage -Message "Impossible to retrieve file $($OnlineFile.FileName) from Source Download path. Error : $($_.Exception)" -Level Warning; 
                }
                if (-not $WhatIf) { $WebResult | Set-ESIContent -Path ($ScriptAddonCachePath + $OnlineFile.FileName) }
                else { Write-LogMessage -Message "WhatIf mode, no file will be created - Tested file : $ScriptAddonCachePath$($OnlineFile.FileName)" }
            }
        }
        else {
            Write-LogMessage -Message "Configuration is up to date without any update needed"; 
        }
    }
    else {
        Write-LogMessage -Message "Runbook mode, no need to update configuration, directly downloaded from Github";
    }
}

function Invoke-AzureAutomationCmd
{
    Param(
        $Body,
        $Runbook
    )
    
    if ($null -eq $Script:AccessToken)
    {
        Write-LogMessage -Message ("Connect to Management Azure RestAPI ...")
        Write-LogMessage -Message "Connect to Azure RM"

        if (-not $Global:AlreadyAzConnected)
        {
            # Ensures you do not inherit an AzContext in your runbook
            Disable-AzContextAutosave -Scope Process
            
            if ($isRunbook)
            {
                # Connect to Azure with system-assigned managed identity
                $AzureContext = (Connect-AzAccount -Identity).context
            }
            else {
                if ($Global:Interactive)
                {
                    Write-LogMessage -Message "Az Connect with Interactive Logon"
                    $AzureContext = (Connect-AzAccount).context
                }
                else {
                    Write-LogMessage -Message "Az Connect with Interactive Logon"
                    $AzureContext = (Connect-AzAccount -CertificateThumbprint $Script:MGGraphAzureRMCertificate -Tenant $Script:TenantName -ApplicationId $Script:MGGraphAzureRMAppId).context
                }
            }
            $Global:AlreadyAzConnected = $true
        }
        else {$AzureContext = Get-AzContext}

        $context = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile.DefaultContext

        $Script:AccessToken = [Microsoft.Azure.Commands.Common.Authentication.AzureSession]::Instance.AuthenticationFactory.Authenticate($context.Account, $context.Environment, $context.Tenant.Id.ToString(), $null, [Microsoft.Azure.Commands.Common.Authentication.ShowDialog]::Never, $null, "https://management.azure.com/")

    }

    try {
    
        # Draft
        $headerParams = @{'Authorization'="Bearer $($script:AccessToken.AccessToken)"}
        $url="https://management.azure.com/subscriptions/$($script:AutomationConfiguration.SubscriptionId)/resourceGroups/$($script:AutomationConfiguration.resourceGroup)/providers/Microsoft.Automation/automationAccounts/$($script:AutomationConfiguration.automationAccountName)/runbooks/$Runbook/draft/content?api-version=2019-06-01"
        
        if (-not $whatif) { 
            $results=Invoke-RestMethod -Uri $url -Headers $headerParams -Method Put -Body $body
            Write-Output $results.value
        }
        else {
            Write-LogMessage -Message "WhatIf mode, Simulate Put request to $url with body $body"
        }


        # Publish
        $url="https://management.azure.com/subscriptions/$($script:AutomationConfiguration.SubscriptionId)/resourceGroups/$($script:AutomationConfiguration.resourceGroup)/providers/Microsoft.Automation/automationAccounts/$($script:AutomationConfiguration.automationAccountName)/runbooks/$Runbook/publish?api-version=2019-06-01"
        
        if (-not $whatif) { $results=Invoke-RestMethod -Uri $url -Headers $headerParams -Method POST }
        else { Write-LogMessage -Message "WhatIf mode, Simulate Post request to $url" }
    
    }
    catch {
        Write-LogMessage -Message "Error while publishing runbook $Runbook. Error : $($_.Exception)" -Level Warning; 
    }

}

function Get-AzureAutomationRunbook
{
    Param(
        $Runbook
    )
    
    if ($null -eq $Script:AccessToken)
    {
        Write-LogMessage -Message ("Connect to Management Azure RestAPI ...")
        Write-LogMessage -Message "Connect to Azure RM"

        if (-not $Global:AlreadyAzConnected)
        {
            # Ensures you do not inherit an AzContext in your runbook
            Disable-AzContextAutosave -Scope Process | out-null
            
            if ($isRunbook)
            {
                # Connect to Azure with system-assigned managed identity
                $AzureContext = (Connect-AzAccount -Identity).context
            }
            else {
                if ($Global:Interactive)
                {
                    Write-LogMessage -Message "Az Connect with Interactive Logon"
                    $AzureContext = (Connect-AzAccount).context
                }
                else {
                    Write-LogMessage -Message "Az Connect with Interactive Logon"
                    $AzureContext = (Connect-AzAccount -CertificateThumbprint $Script:MGGraphAzureRMCertificate -Tenant $Script:TenantName -ApplicationId $Script:MGGraphAzureRMAppId).context
                }
            }
            $Global:AlreadyAzConnected = $true
        }
        else {$AzureContext = Get-AzContext}

        $context = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile.DefaultContext

        $Script:AccessToken = [Microsoft.Azure.Commands.Common.Authentication.AzureSession]::Instance.AuthenticationFactory.Authenticate($context.Account, $context.Environment, $context.Tenant.Id.ToString(), $null, [Microsoft.Azure.Commands.Common.Authentication.ShowDialog]::Never, $null, "https://management.azure.com/")

    }

    try {
    
        $headerParams = @{'Authorization'="Bearer $($script:AccessToken.AccessToken)"}
        $url="https://management.azure.com/subscriptions/$($script:AutomationConfiguration.SubscriptionId)/resourceGroups/$($script:AutomationConfiguration.resourceGroup)/providers/Microsoft.Automation/automationAccounts/$($script:AutomationConfiguration.automationAccountName)/runbooks/$Runbook/content?api-version=2019-06-01"
        Write-LogMessage -Message "Get to URL $url "
        $results=Invoke-RestMethod -Uri $url -Headers $headerParams -Method GET

        return $results
    
    }
    catch {
        Write-LogMessage -Message "Error while publishing runbook $Runbook. Error : $($_.Exception)" -Level Warning; 
    }

}

function Invoke-ESIWebRequest
{
    Param(
        $Uri
    )

    $object = $null

    if ($script:Useproxy)
    {
        $object = (Invoke-WebRequest -Uri $Uri -UseBasicParsing -Proxy $Script:ProxyUrl).Content
    }
    else
    {
        $object = (Invoke-WebRequest -Uri $Uri -UseBasicParsing).Content
    }

    return $object
}

function Get-VersionTrackingFromOnline
{
    try {
        
        if ($Script:BetaVersion)
        {
            $VersionTracking = Invoke-ESIWebRequest -Uri "https://aka.ms/BetaESICollectorVersionTracking"
        }
        else {
            $VersionTracking = Invoke-ESIWebRequest -Uri "https://aka.ms/ESICollectorVersionTracking"
        }
    }
    catch {
        Write-LogMessage "Unable to get version tracking file from https://aka.ms/ESICollectorVersionTracking. Exception $($_.Exception); Fatal Error" -Level Error
        return $null
    }

    $VersionTracking = $VersionTracking | ConvertFrom-Json

    return $VersionTracking
}

function Update-ScriptFromInternet
{
    Param(
        [Parameter(Mandatory=$false)] [string] $TargetPath,
        [Parameter(Mandatory=$false)] [string] $SpecificTargetVersion,
        [Parameter(Mandatory=$false)] [int] $InternalSpecificVersion,
        [Parameter(Mandatory=$true)] [int] $InternalVersionCurentFile,
        [Parameter(Mandatory=$True)] [string] $CurrentVersion,
        [switch] $DownloadOnly,
        [switch] $ForceUpdate
    )
    
    $VersionTracking = Get-VersionTrackingFromOnline

    if (-not [string]::IsNullOrEmpty($SpecificTargetVersion)) {
        $TargetVersion = $VersionTracking.VersionHistory | Where-Object { $_.Version -eq $SpecificTargetVersion }
        if ($Script:VersionRollback)
        {
            $VersionUpgradePath = $VersionTracking.VersionHistory | Where-Object { $_.InternalVersion -ge $InternalSpecificVersion -and $_.InternalVersion -lt $InternalVersionCurentFile }
        }
        else
        {
            $VersionUpgradePath = $VersionTracking.VersionHistory | Where-Object { $_.InternalVersion -le $InternalSpecificVersion -and $_.InternalVersion -gt $InternalVersionCurentFile }
        }

        if ([string]::IsNullOrEmpty($TargetVersion)) {
            Write-LogMessage "Unable to find the requested version $SpecificTargetVersion in the version tracking file, this version doesn't exist. Please check the version number and try again" -Level Error
            exit
        }
    }
    else {
        [int] $InternalTargetVersion = $VersionTracking.LatestVersion -replace "\.",""
        $TargetVersion = $VersionTracking.VersionHistory | Where-Object { $_.Version -eq $VersionTracking.LatestVersion }

        if ($InternalTargetVersion -gt $InternalVersionCurentFile) {
            $VersionUpgradePath = $VersionTracking.VersionHistory | Where-Object { $_.InternalVersion -gt $InternalVersionCurentFile }
        }
        else {
            Write-LogMessage "No update available, current version is $CurrentVersion, latest version is $($VersionTracking.LatestVersion)" -Level Warning
            if ($ForceUpdate -or $DownloadOnly) {
                Write-LogMessage "Download Only Mode or ForceUpdate switch is used, current file will be rewritten with original file" -Level Warning
                $VersionUpgradePath = $VersionTracking.VersionHistory | Where-Object { $_.InternalVersion -gt $InternalVersionCurentFile }
            }
            else {
                return
            }
        }
    }

    if (-not $DownloadOnly) {

        # for each version in VersionUpgradePath, verify that there is BreakingChanges and add it in the $BreakingChanges table variable if the Target is equal to 'On-Premises' or 'All'
        $BreakingChanges = @()
        foreach ($Version in $VersionUpgradePath) {
            if ($null -ne $Version.BreakingChanges) {
                foreach ($BreakingChange in $Version.BreakingChanges) {
                    if ($BreakingChange.Target -eq "On-Premises" -or $BreakingChange.Target -eq "All") {
                        $BreakingChanges += $BreakingChange
                    }
                }
            }
        }

        if ($BreakingChanges.Count -gt 0) {
            Write-LogMessage "The following Breaking Changes could be applied only if 'ForceUpdate' switch is used as those changes need manual configuration/changes :"
            foreach ($BreakingChange in $BreakingChanges) {
                Write-LogMessage "    $($BreakingChange.Description)"
            }

            if ($ForceUpdate) {
                Write-LogMessage "ForceUpdate switch was used, the Collector will be updated"
            }
            else {
                Write-LogMessage "ForceUpdate switch was not used, the Collector will not be updated"
                return
            }
        }
    }
    else {
        Write-LogMessage "Download only mode, the Collector will be downloaded to the version $($TargetVersion.Version)"     
        #Write the VersionTracking file in the target folder
        if (-not $WhatIf) { $VersionTracking | ConvertTo-Json | Set-ESIContent -Path "$TargetPath\ESICollectorVersionTracking.json" }
        else { Write-LogMessage "WhatIf mode, no file will be created - Tested file : $TargetPath\ESICollectorVersionTracking.json" }
    }

    Write-LogMessage "Target version is $($TargetVersion.Version)"
        
    if ($TargetVersion.Beta)
    {
        $SourcePath = "$($VersionTracking.ESICollectorRawRepository)/Beta/$($TargetVersion.VersionFileName)"
    }
    else 
    { 
        $SourcePath = "$($VersionTracking.ESICollectorRawRepository)/$($TargetVersion.VersionFileName)"
    }

    # Download the file
    try {
        $DownloadedFile = Invoke-ESIWebRequest -Uri $SourcePath
    }
    catch {
        Write-LogMessage "Unable to download the file $SourcePath. Exception $($_.Exception); Fatal Error" -Level Error
        exit
    }

    $script:ConfigurationTargetVersion = @{}

    if (-not $DownloadOnly) 
    { 
        Start-ScriptBackup 
        $UpdateName = "downloaded"
    }
    else {$UpdateName = "updated"}

    if ($Global:isRunbook) {
        $DownloadedFile = [System.IO.MemoryStream]::new($DownloadedFile)
        $ZipFile = [System.IO.Compression.ZipArchive]::new($DownloadedFile)
        $files = $ZipFile.Entries | Where-Object { $_.Name -in $Script:FileListToCopy }
        $files | ForEach-Object {
            if ($_.Name -in $Script:AdvancedFilesToIgnore) 
            {
                Write-LogMessage "File : $($_.Name) will be ignored for the update."
                continue; 
            }
            Write-LogMessage "File : $($_.Name) will be updated to the version $($TargetVersion.Version) in the Runbook."
            $File = $_
            $FileContent = $File.Open()

            switch ($File.Name) {
                "CollectExchSecIns.ps1" {
                    Invoke-AzureAutomationCmd -Body $FileContent -Runbook "Start-ESICollector"
                }
                "Updater.ps1" {
                    Invoke-AzureAutomationCmd -Body $FileContent -Runbook "Updater"
                }
                "UpdaterConfig.json"
                {
                    # extract filestream to string
                    $StreamReader = [System.IO.StreamReader]::new($FileContent)
                    $script:ConfigurationTargetVersion[$File.Name] = $StreamReader.ReadToEnd()
                    $StreamReader.Close()

                    $script:ConfigurationTargetVersion[$File.Name] = $ConfigurationTargetVersion[$File.Name] | ConvertFrom-Json
                }
                "CollectExchSecConfiguration.json" {
                    # extract filestream to string
                    $StreamReader = [System.IO.StreamReader]::new($FileContent)
                    $script:ConfigurationTargetVersion[$File.Name] = $StreamReader.ReadToEnd()
                    $StreamReader.Close()

                    $script:ConfigurationTargetVersion[$File.Name] = $ConfigurationTargetVersion[$File.Name] | ConvertFrom-Json
                    $Script:ConfigurationTargetVersionLoaded = $true
                }
            }

            $FileContent.Close()
        }

        $ZipFile.Dispose()
    }
    else {
        # Extract the PowerShell script from the downloaded zip file

        try {
            $DownloadedFile = [System.IO.MemoryStream]::new($DownloadedFile)
            $ZipFile = [System.IO.Compression.ZipArchive]::new($DownloadedFile)
            $files = $ZipFile.Entries | Where-Object { $_.Name -in $Script:FileListToCopy }
            $files | ForEach-Object {
                if ($_.Name -in $Script:AdvancedFilesToIgnore) 
                {
                    Write-LogMessage "File : $($_.Name) will be ignored for the update."
                    continue; 
                }
                Write-LogMessage "File : $($_.Name) will be $UpdateName to the version $($TargetVersion.Version)."
                $File = $_
                $FileContent = $File.Open()
                if ($File.Name -in $Script:ConfigFiles) {
                    if ($DownloadOnly) {
                        $TargetConfigName = $File.Name -replace ".json","-ForNewVersion.json"
                        if (-not $Whatif) { $FileContent.CopyTo([System.IO.File]::Create("$TargetPath\$TargetConfigName")) }
                        else { Write-LogMessage "WhatIf mode, no file will be created - Tested file : $TargetPath\$TargetConfigName" }
                    }
                    else {
                        # extract filestream to string
                        $StreamReader = [System.IO.StreamReader]::new($FileContent)
                        $script:ConfigurationTargetVersion[$File.Name] = $StreamReader.ReadToEnd()
                        $StreamReader.Close()

                        $script:ConfigurationTargetVersion[$File.Name] = $ConfigurationTargetVersion[$File.Name] | ConvertFrom-Json
                        $Script:ConfigurationTargetVersionLoaded = $true
                    }
                }
                else 
                { 
                    if (-not $WhatIf) { $FileContent.CopyTo([System.IO.File]::Create("$TargetPath\$($File.Name)")) }
                    else { Write-LogMessage "WhatIf mode, no file will be created - Tested file : $TargetPath\$($File.Name)" }
                }
                $FileContent.Close()
            }

            $ZipFile.Dispose()
        }
        catch {
            Write-LogMessage "Unable to extract the PowerShell script from the downloaded zip file. Exception $($_.Exception); Fatal Error" -Level Error
            return
        }
    }

    if ($DownloadOnly) {
        $Script:EndMessage += "Download only mode, the Collector was downloaded to the folder $TargetPath to version $($TargetVersion.Version)"
    }
    else {
        $Script:EndMessage += "The Collector was updated to the folder $TargetPath to version $($TargetVersion.Version)."
    }
}

function Update-ScriptOfflineMode
{
    Param(
        [Parameter(Mandatory=$True)] [string] $SourcePath,
        [Parameter(Mandatory=$True)] [string] $TargetPath,
        [Parameter(Mandatory=$True)] [string] $CurrentVersion,
        [Parameter(Mandatory=$False)] [string] $SpecificTargetVersion,
        [Parameter(Mandatory=$false)] [int] $InternalSpecificVersion,
        [Parameter(Mandatory=$False)] [switch] $ForceUpdate,
        [Parameter(Mandatory=$true)] [int] $InternalVersionCurentFile

    )
    
    if (Test-Path $SourcePath)
    {
        Write-LogMessage "Offline update mode, the Collector will be updated from the Folder $SourcePath"
        if (-not (Test-Path ($SourcePath + "\CollectExchSecIns.ps1")))
        {
            Write-LogMessage "FATAL - Offline update mode, the file $SourcePath\CollectExchSecIns.ps1 was not found. Please check the path and try again" -Level Error
            exit
        }
        else {
            $SpecificTargetVersion = (Get-Content ($SourcePath + "\CollectExchSecIns.ps1") | Select-String -Pattern "ESICollectorCurrentVersion = " -SimpleMatch).ToString().Split("=")[1].Trim().Replace('"','')
            [int] $InternalSpecificVersion = $SpecificTargetVersion -replace "\.",""
            if ($InternalSpecificVersion -lt 1000) {
                $InternalSpecificVersion = $InternalSpecificVersion * 10
                $SpecificTargetVersion += ".0"
            }
            Write-LogMessage "Target version is $SpecificTargetVersion"

            if ($InternalSpecificVersion -lt $InternalVersionCurentFile) {
                if ($ForceUpdate) {
                    Write-LogMessage "Current Version of the collector is greater than the requested SpecificTargetVersion $SpecificTargetVersion. ForceUpdate switch was used, the Collector will be replaced by the requested old version" -Level Warning
                    $Script:VersionRollback = $true
                }
                else {
                    Write-LogMessage "Current Version of the collector is greater than the requested SpecificTargetVersion $SpecificTargetVersion. Rollback is forbidden without 'ForceUpdate' switch" -Level Error
                    exit
                }
            }
        }

        if (-not (Test-Path ($SourcePath + "\Updater.ps1")))
        {
            Write-LogMessage "Offline update mode, the file $SourcePath\Updater.ps1 was not found. Please check the path and try again" -Level Warning
            $Script:UpdaterFileNotFound = $true
        }

        if (-not (Test-Path ($SourcePath + "\setup.ps1")))
        {
            Write-LogMessage "Offline update mode, the file $SourcePath\setup.ps1 was not found. Please check the path and try again" -Level Warning
            $Script:SetupFileNotFound = $true
        }

        if (-not (Test-Path ($SourcePath + "\ESICollectorVersionTracking.json")))
        {
            Write-LogMessage "FATAL - Offline update mode, the file $SourcePath\ESICollectorVersionTracking.json was not found. Please check the path and try again" -Level Error
            exit
        }
    }
    else
    {
        Write-LogMessage "Offline update mode, the file $SourcePath was not found. Please check the path and try again" -Level Error
        exit
    }

    # load json file to get the version
    $VersionTracking = Get-Content "$SourcePath\ESICollectorVersionTracking.json" | ConvertFrom-Json
    
    $TargetVersion = $VersionTracking.VersionHistory | Where-Object { $_.Version -eq $SpecificTargetVersion }
    if ($Script:VersionRollback)
    {
        $VersionUpgradePath = $VersionTracking.VersionHistory | Where-Object { $_.InternalVersion -ge $InternalSpecificVersion -and $_.InternalVersion -lt $InternalVersionCurentFile }
    }
    else
    {
        $VersionUpgradePath = $VersionTracking.VersionHistory | Where-Object { $_.InternalVersion -le $InternalSpecificVersion -and $_.InternalVersion -gt $InternalVersionCurentFile }
    }

    if ([string]::IsNullOrEmpty($TargetVersion)) {
        Write-LogMessage "Unable to find the requested version $SpecificTargetVersion in the version tracking file. Please check the version number and try again" -Level Error
        exit
    }

    # for each version in VersionUpgradePath, verify that there is BreakingChanges and add it in the $BreakingChanges table variable if the Target is equal to 'On-Premises' or 'All'
    $BreakingChanges = @()
    foreach ($Version in $VersionUpgradePath) {
        if ($null -ne $Version.BreakingChanges) {
            foreach ($BreakingChange in $Version.BreakingChanges) {
                if ($BreakingChange.Target -eq "On-Premises" -or $BreakingChange.Target -eq "All") {
                    $BreakingChanges += $BreakingChange
                }
            }
        }
    }

    if ($BreakingChanges.Count -gt 0) {
        Write-LogMessage "The following Breaking Changes could be applied only if 'ForceUpdate' switch is used as those changes need manual configuration/changes :"
        foreach ($BreakingChange in $BreakingChanges) {
            Write-LogMessage "    $($BreakingChange.Description)"
        }

        if ($ForceUpdate) {
            Write-LogMessage "ForceUpdate switch was used, the Collector will be updated"
        }
        else {
            Write-LogMessage "ForceUpdate switch was not used, the Collector will not be updated"
            exit
        }
    }

    Start-ScriptBackup

    # try to copy files from sourcePath to targetPath
    try {
        if (-not $WhatIf)
        {
            Copy-Item -Path "$SourcePath\CollectExchSecIns.ps1" -Destination "$TargetPath\CollectExchSecIns.ps1" -Force
            if(-not $Script:UpdaterFileNotFound) { Copy-Item -Path "$SourcePath\Updater.ps1" -Destination "$TargetPath\Updater.ps1" -Force }
            if(-not $Script:SetupFileNotFound) { Copy-Item -Path "$SourcePath\setup.ps1" -Destination "$TargetPath\setup.ps1" -Force }
        }
        else {
            Write-LogMessage "WhatIf mode, no file will be created - Tested file : $TargetPath\CollectExchSecIns.ps1"
            Write-LogMessage "WhatIf mode, no file will be created - Tested file : $TargetPath\Updater.ps1"
            Write-LogMessage "WhatIf mode, no file will be created - Tested file : $TargetPath\setup.ps1"
        }
    }
    catch {
        Write-LogMessage "Unable to copy the files from $SourcePath to $TargetPath. Exception $($_.Exception); Fatal Error" -Level Error
        exit
    }

    # Create a directory 'Done' in SourcePath and move the files in it
    try {
        if (-not $WhatIf) { New-Item -Path "$SourcePath\Done" -ItemType Directory -Force }
        else { Write-LogMessage "WhatIf mode, no directory will be created - Tested directory : $SourcePath\Done" }

        # Create a directory with the date as suffix
        $Date = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
        if (-not $WhatIf) { New-Item -Path "$SourcePath\Done\$Date" -ItemType Directory -Force }
        else { Write-LogMessage "WhatIf mode, no directory will be created - Tested directory : $SourcePath\Done\$Date" }
        $Script:TargetMove = "$SourcePath\Done\$Date"

        if (-not $WhatIf) { 
            Move-Item -Path "$SourcePath\CollectExchSecIns.ps1" -Destination "$TargetMove\CollectExchSecIns.ps1" -Force
            if(-not $Script:UpdaterFileNotFound) { Move-Item -Path "$SourcePath\Updater.ps1" -Destination "$TargetMove\Updater.ps1" -Force }
            if(-not $Script:SetupFileNotFound) { Move-Item -Path "$SourcePath\setup.ps1" -Destination "$TargetMove\setup.ps1" -Force }
            Move-Item -Path "$SourcePath\ESICollectorVersionTracking.json" -Destination "$TargetMove\ESICollectorVersionTracking.json" -Force
        }
        else {
            Write-LogMessage "WhatIf mode, no file will be moved - Tested file : $SourcePath\CollectExchSecIns.ps1"
            Write-LogMessage "WhatIf mode, no file will be moved - Tested file : $SourcePath\Updater.ps1"
            Write-LogMessage "WhatIf mode, no file will be moved - Tested file : $SourcePath\setup.ps1"
            Write-LogMessage "WhatIf mode, no file will be moved - Tested file : $SourcePath\ESICollectorVersionTracking.json"
        }
    }
    catch {
        Write-LogMessage "Unable to create the directory $TargetMove or move the files in it. Exception $($_.Exception); Fatal Error" -Level Error
    }

    $Script:EndMessage += "The Collector was updated to the folder $TargetPath to version $($TargetVersion.Version)."
}

function Get-CurrentVersionOfScript
{
    Param(
        [string] $TargetPath
    )

    $Script:CurrentVersion = "0.0"
    $Script:InternalVersionCurentFile = 0

    if (-not $DownloadOnly)
    {
        if ($Global:isRunbook) {
            
            try {
                $Script:CurrentVersion =([regex]::Match($script:RunbookContent,"ESICollectorCurrentVersion = `"(?<Version>[0-9.]*)`"")).Groups["Version"].Value
                Write-LogMessage "Current version is $($Script:CurrentVersion)"
            }
            catch {
                $Script:CurrentVersion = "0.0"
                Write-LogMessage "Current version was not found on the Runbook Start-ESICollector, Regex no result"
            }
            

            if ([string]::IsNullOrEmpty($CurrentVersion))
            {
                $Script:CurrentVersion = "0.0"
                Write-LogMessage "Current version was not found on the Runbook Start-ESICollector, file not found"
            }

            [int] $Script:InternalVersionCurentFile = $CurrentVersion -replace "\.",""
            if ($InternalVersionCurentFile -lt 1000) {
                $Script:InternalVersionCurentFile = $InternalVersionCurentFile * 10
            }
        }
        else {
            # Verify Current version
            if (Test-Path ($TargetPath + "\CollectExchSecIns.ps1"))
            {
                $Script:CurrentVersion = (Get-Content ($TargetPath + "\CollectExchSecIns.ps1") | Select-String -Pattern "ESICollectorCurrentVersion = " -SimpleMatch).ToString().Split("=")[1].Trim().Replace('"','')
                Write-LogMessage "Current version is $CurrentVersion"

                if ([string]::IsNullOrEmpty($CurrentVersion))
                {
                    $Script:CurrentVersion = "0.0"
                    Write-LogMessage "Current version was not found on the file $TargetPath\CollectExchSecIns.ps1, file not found"
                }
            }
            else
            {
                $Script:CurrentVersion = "0.0"
                Write-LogMessage "Current version was not found on the file $TargetPath\CollectExchSecIns.ps1, file not found"
            }

            [int] $Script:InternalVersionCurentFile = $CurrentVersion -replace "\.",""
            if ($InternalVersionCurentFile -lt 1000) {
                $Script:InternalVersionCurentFile = $InternalVersionCurentFile * 10
            }
        }
    }

    if (-not [string]::IsNullOrEmpty($SpecificTargetVersion)) {
        [int] $InternalSpecificVersion = $SpecificTargetVersion -replace "\.",""
        if (([string]$InternalSpecificVersion).length -ne 4) {
            Write-LogMessage "SpecificTargetVersion parameter is not valid, please use the format X.X.X.X" -Level Error
            exit
        }
    
        if ($InternalSpecificVersion -lt $InternalVersionCurentFile) {
            if ($ForceUpdate) {
                Write-LogMessage "Current Version of the collector is greater than the requested SpecificTargetVersion $SpecificTargetVersion. ForceUpdate switch was used, the Collector will be replaced by the requested old version" -Level Warning
                $Script:VersionRollback = $true
            }
            else {
                Write-LogMessage "Current Version of the collector is greater than the requested SpecificTargetVersion $SpecificTargetVersion. Rollback is forbidden without 'ForceUpdate' switch" -Level Error
                exit
            }
        }
    }

    $Script:CurrentVersion = $CurrentVersion
    $Script:InternalVersionCurentFile = $InternalVersionCurentFile
}

function CheckConfigurationFile
{
    Param(
        $ConfigurationCurrentVersion,
        $ConfigurationTargetVersion,
        $TargetVersion,
        [switch] $ApplyUpdate
    )

    if ($ConfigurationCurrentVersion.SolutionMetadata.JSonVersion -ne $ConfigurationTargetVersion.SolutionMetadata.JSonVersion)
    {
        Write-LogMessage "The version of the target configuration file $($ConfigurationTargetVersion.SolutionMetadata.JSonVersion) is not the same as the version of the script $($ConfigurationCurrentVersion.SolutionMetadata.JSonVersion). Configuration file need to be updated." -Level Warning
    
        $ConfigurationCurrentVersion.SolutionMetadata = $ConfigurationTargetVersion.SolutionMetadata
        $Script:MissingParameters = $true
    }

    Write-Host "`nConfiguration file will be verified to see if missing parameter has to be added." -ForegroundColor Green
    $Script:ParameterErrorList = CheckRecursive -JsonSegment $ConfigurationTargetVersion -JsonTestSegment $ConfigurationCurrentVersion -TestType $TargetVersion -ApplyUpdate:$ApplyUpdate

    if ($null -ne $ParameterErrorList -and $ParameterErrorList.ErrorCount -gt 0)
    {
        Write-LogMessage "The following parameters are missing or have changed :"
        foreach ($ParameterError in $Script:ParameterErrorList.TotalList)
        {
            Write-LogMessage "    $($ParameterError.ErrorMessage)"
        }

        if (-not $ConfigFileReadOnly) {Write-LogMessage "The configuration file will be updated with the missing parameters."}
        else {Write-LogMessage "The configuration file will not be updated because it is read only."}
        $Script:MissingParameters = $true
    }
}

function Get-ConfigurationTargetVersionJson
{
    Param(
        [string] $TargetPath
    )

    Write-LogMessage "Get the configuration file from the repository."
    $VersionTracking = Get-VersionTrackingFromOnline

    Write-LogMessage "The latest version of the Script file is $($VersionTracking.LatestVersion)."

    $TargetVersion = $VersionTracking.VersionHistory | Where-Object { $_.Version -eq $VersionTracking.LatestVersion }
    
    if ($TargetVersion.Beta)
    {
        $SourcePath = "$($VersionTracking.ESICollectorRawRepository)/Beta/$($TargetVersion.VersionFileName)"
    }
    else 
    { 
        $SourcePath = "$($VersionTracking.ESICollectorRawRepository)/$($TargetVersion.VersionFileName)"
    }
    
     # Download the file
     try {
        $DownloadedFile = Invoke-ESIWebRequest -Uri $SourcePath
    }
    catch {
        Write-LogMessage "Unable to download the file $SourcePath. Exception $($_.Exception); Fatal Error" -Level Error
        return
    }

    Write-LogMessage "Extracting the configuration file from the downloaded zip file"
    $script:ConfigurationTargetVersion = @{}
    
    try {
        $DownloadedFile = [System.IO.MemoryStream]::new($DownloadedFile)
        $ZipFile = [System.IO.Compression.ZipArchive]::new($DownloadedFile)
        $files = $ZipFile.Entries | Where-Object { $_.Name -in $Script:ConfigFiles }
        $files | ForEach-Object {
            $File = $_
            $FileContent = $File.Open()
            if ($File.Name -in $Script:ConfigFiles) {
                Write-LogMessage "Processing $($File.Name) file"
                if ($DownloadOnly) {
                    
                    $ConfigfileTargetName = $File.Name -replace ".json","-ForNewVersion.json"
                    if (-not $WhatIf) { $FileContent.CopyTo([System.IO.File]::Create("$TargetPath\$ConfigfileTargetName")) }
                    else { Write-LogMessage "WhatIf mode, no file will be created - Tested file : $TargetPath\$ConfigfileTargetName" }
                }
                else {
                    Write-LogMessage "Write Extracted file in StrreamReader"
                    # extract filestream to string
                    $StreamReader = [System.IO.StreamReader]::new($FileContent)
                    $script:ConfigurationTargetVersion[$File.Name] = $StreamReader.ReadToEnd()
                    $StreamReader.Close()
                    
                    Write-LogMessage "Convert Json to Object"
                    $script:ConfigurationTargetVersion[$File.Name] = $script:ConfigurationTargetVersion[$File.Name] | ConvertFrom-Json
                    $Script:ConfigurationTargetVersionLoaded = $true
                }
            }
            $FileContent.Close()
        }

        $ZipFile.Dispose()
    }
    catch {
        Write-LogMessage "Unable to extract the PowerShell script from the downloaded zip file. Exception $($_.Exception); Fatal Error" -Level Error
        return
    }
}

function Save-ConfigurationTargetVersion
{
    Param(
        $ConfigurationTargetVersion,
        [string] $TargetPath,
        [string] $targetFile
    )

    Start-ScriptBackup

    $ConfigInJSON = $ConfigurationTargetVersion | ConvertTo-Json -Depth 15

    if ($global:isRunbook) {
        if (-not $WhatIf) { Set-AutomationVariable -Name "GlobalConfiguration" -Value $ConfigInJSON.ToString() }
        else { Write-LogMessage "WhatIf mode, Simulate Set GlobalConfiguration with New Json" }

    }
    else {
        if (-not $WhatIf) { $ConfigInJSON | Set-ESIContent -Path "$TargetPath\Config\$targetFile" }
        else { Write-LogMessage "WhatIf mode, no file will be created - Tested file : $TargetPath\Config\$targetFile" }
    }
}

if (-not $Global:isRunbook )
{
    $scriptFolder = Split-Path -Parent $MyInvocation.MyCommand.Definition
    $Script:scriptFolder = $scriptFolder
    $ScriptLogPath = $scriptFolder + '\Logs'

    Push-Location ($scriptFolder);
    if (! (Test-Path $ScriptLogPath)) { mkdir $ScriptLogPath }

    $ScriptLogFile = "$ScriptLogPath\Updater-$DateSuffixForFile.log"
    Start-Transcript -Path $ScriptLogFile

    CleanFiles -ScriptLogPath $ScriptLogPath -ClearFilesOlderThan $ClearFilesOlderThan
}

# Connect to Automation Account to modify a Runbook
if ($Global:isRunbook) {
  
    # Get the Runbook Start-ESICollector
    #$script:RunbookContent = Get-AzAutomationRunbook -ResourceGroupName $script:resourceGroup -AutomationAccountName $script:automationAccountName -Name "Start-ESICollector"
    
    $script:RunbookContent = Get-AzureAutomationRunbook -Runbook "Start-ESICollector"

    if ($null -eq $RunbookContent) {
        Write-LogMessage "Unable to get the Runbook Start-ESICollector. Fatal Error" -Level Error
        exit
    }
}

try {
    LoadConfiguration -configurationFile $JSONFileCondiguration -VariableFromAzureAutomation:$Global:isRunbook -ErrorAction Stop
}
catch {
    Write-LogMessage -Message "Configuration not loaded. Impossible to continue - Exception: $($_.Exception.Message) `n StackTrace: $($_.ScriptStackTrace) `n PositionMessage: $($_.InvocationInfo.PositionMessage)"
    if (-not $Global:isRunbook ) { Stop-Transcript }
    throw "Fatal Error, unable to continue - Exception: $($_.Exception.Message) `n StackTrace: $($_.ScriptStackTrace) `n PositionMessage: $($_.InvocationInfo.PositionMessage)"
    return -1
}

if ($Script:UpdateTypeConfiguration.UpdateSourceType -eq "Internet")
{
    try {
        Get-VersionTrackingFromOnline | Out-Null
    }
    catch {
        Write-LogMessage "Unable to get version tracking file from https://aka.ms/ESICollectorVersionTracking. Exception $($_.Exception); Fatal Error" -Level Error
        Write-LogMessage "Please check your internet connection and try again or use the Offline mode" -Level Error
        exit
    }
}

Get-CurrentVersionOfScript -TargetPath $Script:ServerConfiguration.LocalTargetPath

#region Update the script
    if ($Script:UpdateTypeConfiguration.UpdateType -eq "Full" -or $Script:UpdateTypeConfiguration.UpdateType -eq "ScriptOnly" `
        -or ($Script:UpdateTypeConfiguration.UpdateType -eq "Partial" -and $Script:UpdateTypeConfiguration.PartialUpdateType -contains "Script"))
    {
        switch ($Script:UpdateTypeConfiguration.UpdateSourceType)
        {
            "Internet" {
                switch ($Script:UpdateTypeConfiguration.UpdateTargetType)
                {
                    "Download" {
                        Update-ScriptFromInternet -TargetPath $Script:UpdateTypeConfiguration.UpdateTargetTypeLocalPath `
                            -CurrentVersion $CurrentVersion -SpecificTargetVersion $SpecificTargetVersion `
                            -ForceUpdate:$Script:ForceUpdate -DownloadOnly:$true `
                            -InternalSpecificVersion $InternalSpecificVersion -InternalVersionCurentFile $InternalVersionCurentFile
                    }
                    "Replace" {
                        Update-ScriptFromInternet -TargetPath $Script:ServerConfiguration.LocalTargetPath `
                            -CurrentVersion $CurrentVersion -SpecificTargetVersion $SpecificTargetVersion `
                            -ForceUpdate:$Script:ForceUpdate -DownloadOnly:$false `
                            -InternalSpecificVersion $InternalSpecificVersion -InternalVersionCurentFile $InternalVersionCurentFile
                    }
                    default {
                        Write-LogMessage "UpdateTargetType parameter is not valid, please use 'Download', 'Replace'" -Level Error
                        exit
                    }
                }
            }
            "Local" {
                Update-ScriptOfflineMode -SourcePath $Script:UpdateTypeConfiguration.UpdateSourceTypeLocalPath -TargetPath $Script:ServerConfiguration.LocalTargetPath `
                    -CurrentVersion $CurrentVersion -SpecificTargetVersion $SpecificTargetVersion `
                    -ForceUpdate:$ForceUpdate `
                    -InternalSpecificVersion $InternalSpecificVersion -InternalVersionCurentFile $InternalVersionCurentFile
            }
        }
    }
#endRegion

#region Update the configuration file
    if ($Script:UpdateTypeConfiguration.UpdateType -eq "Full" -or $Script:UpdateTypeConfiguration.UpdateType -eq "ConfigOnly" `
        -or ($Script:UpdateTypeConfiguration.UpdateType -eq "Partial" -and $Script:UpdateTypeConfiguration.PartialUpdateType -in  ("Config", "CompareConfig")))
    {
        if ($Script:UpdateTypeConfiguration.UpdateTargetType -eq "Download")
        {
            Write-LogMessage "Config update is not supported with DownloadOnly switch. Files can only be downloaded" -Level Warning
        }
        else {
        
            if ($Script:UpdateTypeConfiguration.UpdateType -eq "Partial" -and $Script:UpdateTypeConfiguration.PartialUpdateType -eq "CompareConfig")
            {
                $ConfigFileReadOnly = $true
            }
            else { $ConfigFileReadOnly = $false }

            foreach ($ConfigFile in $Script:ConfigFiles)
            {
                try 
                {
                    $ConfigFileNew = $ConfigFile -replace ".json","-ForNewVersion.json"

                    switch ($Script:UpdateTypeConfiguration.UpdateSourceType)
                    {
                        "Internet" {
                            if (-not $Script:ConfigurationTargetVersionLoaded) { Get-ConfigurationTargetVersionJson -TargetPath $Script:ServerConfiguration.LocalTargetPath }

                            if ($Global:isRunbook) {
                                $ConfigurationCurrentVersion = Get-AutomationVariable -Name "GlobalConfiguration" -ErrorAction Stop | ConvertFrom-Json
                            }
                            else {
                                $ConfigurationCurrentVersion = Get-Content "$($Script:ServerConfiguration.LocalTargetPath)\Config\$ConfigFile" -Raw | ConvertFrom-Json
                            }
                        }
                        "Local" {         
                            if ($null -eq  $Script:ConfigurationTargetVersion) {$Script:ConfigurationTargetVersion=@{}}

                            if ((Test-Path "$($Script:UpdateTypeConfiguration.UpdateSourceTypeLocalPath)\$ConfigFileNew"))
                            {
                                $Script:ConfigurationTargetVersion[$ConfigFile] = Get-Content -Path "$($Script:UpdateTypeConfiguration.UpdateSourceTypeLocalPath)\$ConfigFileNew" | ConvertFrom-Json
                            }
                            else {
                                Write-LogMessage "The file $ConfigFileNew was not found in the source directory. The configuration file will not be compared." -Level Warning
                                $Script:EndMessageLevel = "Warning"; $Script:EndMessage += "The file $ConfigFileNew was not found in the source directory. The configuration file will not be compared."
                                continue
                            }

                            $ConfigurationCurrentVersion = Get-Content "$($Script:ServerConfiguration.LocalTargetPath)\Config\$ConfigFile" -Raw | ConvertFrom-Json
            
                            if (-not [string]::IsNullOrEmpty($script:TargetMove)) 
                            { 
                                if (-not $WhatIf) { Move-Item -Path "$($Script:UpdateTypeConfiguration.UpdateSourceTypeLocalPath)\$ConfigFileNew" -Destination "$script:TargetMove\$ConfigFileNew" -Force }
                                else { Write-LogMessage "WhatIf mode, no file will be moved - Tested file : $($Script:UpdateTypeConfiguration.UpdateSourceTypeLocalPath)\$ConfigFileNew" }
                            }
                        }
                    }

                    if ($null -eq $ConfigurationTargetVersion[$ConfigFile])
                    {
                        Write-LogMessage "Unable to load the $ConfigFile file from the target directory, config can't be compared." -Level Warning
                        $Script:EndMessageLevel = "Warning"; $Script:EndMessage += "Unable to load the $ConfigFile file from the target directory, config can't be compared."
                        continue
                    }

                    Write-LogMessage "Configuration file $ConfigFile structure will be verified....."

                    CheckConfigurationFile -ConfigurationTargetVersion $ConfigurationTargetVersion[$ConfigFile] -ConfigurationCurrentVersion $ConfigurationCurrentVersion -TargetVersion "$($TargetVersion.Version)" -ApplyUpdate:(-not $ConfigFileReadOnly)
                
                    if ($Script:MissingParameters) 
                    { 
                        Write-LogMessage "The configuration file $ConfigFile will be updated with the missing parameters."
                        
                        if (-not $ConfigFileReadOnly) { Save-ConfigurationTargetVersion -ConfigurationTargetVersion $ConfigurationCurrentVersion -TargetPath $Script:ServerConfiguration.LocalTargetPath -targetFile $ConfigFile }
                        else { Write-LogMessage "The configuration file will not be updated because it is read only." }
                        $Script:EndMessageLevel = "Warning"; $Script:EndMessage += "Attention, missing parameters, see above." 
                    }
                }
                catch {
                        Write-LogMessage "Unable to load the $ConfigFile file from the target directory or $ConfigFileNew from source directory or compare it with target version. Exception $($_.Exception); Configuration not validated but Script updated." -Level Error
                    }
            }
        }
    }
#endRegion

#region Update the Add-ons
    if ($Script:UpdateTypeConfiguration.UpdateType -eq "Full" -or $Script:UpdateTypeConfiguration.UpdateType -eq "AddOnsOnly" `
    -or ($Script:UpdateTypeConfiguration.UpdateType -eq "Partial" -and $Script:UpdateTypeConfiguration.PartialUpdateType -contains "AddOns"))
    {
        switch ($Script:UpdateTypeConfiguration.UpdateSourceType)
        {
            "Internet" {
                switch ($Script:UpdateTypeConfiguration.UpdateTargetType)
                {
                    "Download" {
                        Write-LogMessage "Start Download Add-Ons from Internet"
                        Start-AddonsDownload -TargetPath $Script:UpdateTypeConfiguration.UpdateTargetTypeLocalPath -Beta:$Script:BetaVersion
        
                        foreach ($Category in $Categories) {
                            Start-AddonsDownload -TargetPath $Script:UpdateTypeConfiguration.UpdateTargetTypeLocalPath -Category $Category -Beta:$Script:BetaVersion
                        }
                    }
                    "Replace" {
                        Write-LogMessage "Start Update Add-Ons Main stream from Internet"
                        Update-AddonsFromInternetRepository -Beta:$Script:BetaVersion -TargetPath $Script:ServerConfiguration.LocalTargetPath

                        foreach ($Category in $Categories) {
                            Write-LogMessage "Start Update Add-Ons Category $Category from Internet"
                            Update-AddonsFromInternetRepository -Beta:$Script:BetaVersion -TargetPath $Script:ServerConfiguration.LocalTargetPath -Category $Category
                        }
                    }
                }
            }
            "Local" {
                Update-AddonsOfflineMode -SourcePath $Script:UpdateTypeConfiguration.UpdateSourceTypeLocalPath -TargetPath $Script:ServerConfiguration.LocalTargetPath

                foreach ($Category in $Categories) {
                    Update-AddonsOfflineMode -SourcePath $Script:UpdateTypeConfiguration.UpdateSourceTypeLocalPath -TargetPath $Script:ServerConfiguration.LocalTargetPath -Category $Category
                }
            }
        }
    }
#endRegion

if ($Script:EndMessage.count -gt 0)
{
    Write-LogMessage "The following messages were generated during the execution of the script :"
    foreach ($Message in $Script:EndMessage)
    {
        Write-LogMessage "    $($Message)" -Level $Script:EndMessageLevel
    }
}

Write-LogMessage -Message ("Updater finished")
Write-Output "`n**************** LOGS **********************"
Write-Output (Get-UDSLogs)
Write-Output "**************** END LOGS **********************`n"

if (-not $Global:isRunbook )
{
    Stop-Transcript
}