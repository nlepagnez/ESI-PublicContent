<#
Disclaimer:
This sample script is not supported under any Microsoft standard support program or service.
The sample script is provided AS IS without warranty of any kind. Microsoft further disclaims
all implied warranties including, without limitation, any implied warranties of merchantability
or of fitness for a particular purpose. The entire risk arising out of the use or performance of
the sample scripts and documentation remains with you. In no event shall Microsoft, its authors,
or anyone else involved in the creation, production, or delivery of the scripts be liable for any
damages whatsoever (including, without limitation, damages for loss of business profits, business
interruption, loss of business information, or other pecuniary loss) arising out of the use of or
inability to use the sample scripts or documentation, even if Microsoft has been advised of the
possibility of such damages
#>
<#
.Synopsis
    This script update the Exchange Configuration for Exchange Security Insight Collector script.
.DESCRIPTION
    This script can check online update and will update current version used with latest version

.EXAMPLE
.INPUTS
    .\Updater.ps1
        
.OUTPUTS
    No Output
.NOTES
    Developed by ksangui@microsoft.com and Nicolas Lepagnez
    Version : 1.0 - Released : Not Released - nilepagn
        - Adding TLS1.2 capability
        - Adding proxy capability
        - Adding support for offline update
        - Adding support for configuration file update
        - Adding support for AddOns update
        - Adding support for Beta version
        - Adding support for Force update
        - Adding support for Categories

        - Missing Documentation

#>

<# 
    Due to incompatibility between Azure Automation and ParameterSet, we need to use the following workaround

Param (
    [Parameter(Mandatory=$True, ParameterSetName = 'Internet')]
    [Parameter(Mandatory=$True, ParameterSetName = 'ConfigurationInternet')] [Switch] $FromInternet,
    
    [Parameter(Mandatory=$False, 
        ParameterSetName = 'Internet', 
        HelpMessage="Download the latest ")] 
    [Parameter(Mandatory=$false, ParameterSetName = 'ConfigurationInternet')]
        [Switch] $DownloadOnly,
    
    [Parameter(Mandatory=$False, ParameterSetName = 'Internet')] $SpecificTargetVersion = $null,
    
    [Parameter(Mandatory=$True, ParameterSetName = 'Offline')]
    [Parameter(Mandatory=$True, ParameterSetName = 'ConfigurationOffline')] [Switch] $OfflineUpdate,
    
    [Parameter(Mandatory=$True, ParameterSetName = 'Offline')]
    [Parameter(Mandatory=$True, ParameterSetName = 'ConfigurationOffline')] [string] $SourcePath,
    
    $TargetPath = $null,
    
    [Parameter(Mandatory=$True, ParameterSetName = 'ConfigurationInternet')]
    [Parameter(Mandatory=$True, ParameterSetName = 'ConfigurationOffline')] [switch] $IncludeAddOnsUpdate,
    
    [Parameter(Mandatory=$False, ParameterSetName = 'ConfigurationInternet')]
    [Parameter(Mandatory=$false, ParameterSetName = 'ConfigurationOffline')] [switch] $UpdateAddonsOnly,

    [Parameter(Mandatory=$False, ParameterSetName = 'ConfigurationInternet')]
    [Parameter(Mandatory=$false, ParameterSetName = 'ConfigurationOffline')] [switch] $IgnoreConfigurationFile,

    [Parameter(Mandatory=$False, ParameterSetName = 'ConfigurationInternet')]
    [Parameter(Mandatory=$false, ParameterSetName = 'ConfigurationOffline')] [switch] $ConfigFileReadOnly,

    [Parameter(Mandatory=$False, ParameterSetName = 'ConfigurationInternet')]
    [Parameter(Mandatory=$false, ParameterSetName = 'ConfigurationOffline')] [switch] $ConfigFileWithoutScriptUpdate,
    
    [Parameter(Mandatory=$false, ParameterSetName = 'ConfigurationInternet')] [switch] $BetaVersion,
    
    [switch] $ForceUpdate,
    
    [Parameter(Mandatory=$false, ParameterSetName = 'ConfigurationInternet')]
    [Parameter(Mandatory=$false, ParameterSetName = 'ConfigurationOffline')] [string[]] $Categories = @("IIS-IoCs","OnlineMessageTracking")
)
#>

Param (
    [bool] $FromInternet = $false,
    
    [bool] $DownloadOnly = $false,
    
    $SpecificTargetVersion = $null,
    
    [bool] $OfflineUpdate = $false,
    
    [string] $SourcePath,
    
    $TargetPath = $null,
    
    [bool] $IncludeAddOnsUpdate = $false,
    
    [bool]$UpdateAddonsOnly = $false,

    [bool] $IgnoreConfigurationFile = $false,

    [bool] $ConfigFileReadOnly = $false,

    [bool] $ConfigFileWithoutScriptUpdate = $false,
    
    [bool]$BetaVersion = $false,
    
    [bool]$ForceUpdate = $false,
    
    [string[]] $Categories = @("IIS-IoCs","OnlineMessageTracking"),

    [switch] $IsOutsideAzureAutomation,

    [bool] $WhatIf = $false
)

$Global:isRunbook = if (-not $IsOutsideAzureAutomation) 
{
    if (!($null -eq (Get-Command "Get-AutomationVariable" -ErrorAction SilentlyContinue)))
    {
        if ($null -eq (Get-Module -Name Orchestrator* -ErrorAction SilentlyContinue))
        {
            $false
        }
        else {$true}
    }
    else {$false}
} else {$false}

$Script:VersionRollback = $false
$InformationPreference = "Continue"

$Useproxy = $false
$Script:ProxyUrl = $null
$DateSuffixForFile = Get-Date -Format "yyyy-MM-dd-HH-mm-ss"
$ClearFilesOlderThan = 7
$Script:ConfigurationTargetVersion = $null

$script:SubscriptionId = "92e84360-5de7-4311-8843-1e4b2ef48d0b"
$script:resourceGroup = "ExchangeSecurity-Test"
$script:automationAccountName = "ESI-DataCollectorTest"
$script:runbookName = "Start-ESICollector"

$Script:EndMessage = @()
$Script:EndMessageLevel = "Info"

Add-Type -AssemblyName System.IO.Compression

function Write-LogMessage {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [string]
        $Message,
        [Parameter(Mandatory=$false)]
        [string]
        $Category="General",
        [Parameter(Mandatory=$false)]
        [ValidateSet("Info","Warning","Error","Verbose")]
        [string]
        $Level="Info",
        [switch] $NoOutput
    )
    $line = "$(Get-Date -f 'yyyy/MM/dd HH:mm:ss')`t$Level`t$Category`t$Message"
    Set-Variable -Name UDSLogs  -Value "$UDSLogs`n$line" -Scope Script
    if($NoOutput -or $Global:DeactivateWriteOutput){
        Write-Host $line
        if ($script:FASTVerboseLevel) { Write-Verbose $line }
    }else{
        Write-Output $line
    }
    switch ($Level) {
        "Verbose" {
            if ($script:FASTVerboseLevel) { Write-Verbose "[VERBOSE] $Category :`t$Message" }
        }
        "Info" {
            Write-Information "[INFO] $Category :`t$Message"
        }
        "Warning" {
            Write-Warning "$Category :`t$Message"
        }
        "Error" {
            Write-Error "$Category :`t$Message"
        }
        Default {}
    }    
}

function CleanFiles
    {
        Param(
            $ClearFilesOlderThan = 7,
            $ScriptLogPath,
            $outputpath = $null
        )

        $DirectoryList = @()
        $DirectoryList += $ScriptLogPath
        if (-not [string]::IsNullOrEmpty($outputpath)) { $DirectoryList += (Split-Path $outputpath) }

        Write-LogMessage "`t ..Cleaning Report and log files older than $ClearFilesOlderThan days."
        $MaxDate = (Get-Date).AddDays($ClearFilesOlderThan*-1)

        $OtherOldFiles = @()
        $FileList = @()
        if ($DirectoryList.count -gt 0)
        {
            foreach ($dir in $DirectoryList)
            {
                if (Test-Path $dir)
                {
                    $OtherPathObj = Get-Item -Path $dir
                    $OtherFiles = $OtherPathObj.GetFiles()
                    $OtherOldFiles = $OtherFiles | Where-Object {$_.LastWriteTime -le $MaxDate}
                    Write-LogMessage ("`t`t There is "+ $OtherFiles.Count + " existing files in $dir with "+ $OtherOldFiles.Count +" files older than $MaxDate.")
                }
                elseif (Test-Path ($scriptFolder + "\" + $dir))
                {
                    $OtherPathObj = Get-Item -Path $dir
                    $OtherFiles = $OtherPathObj.GetFiles()
                    $OtherOldFiles = $OtherFiles | Where-Object {$_.LastWriteTime -le $MaxDate}
                    Write-LogMessage ("`t`t There is "+ $OtherFiles.Count + " existing files in $dir with "+ $OtherOldFiles.Count +" files older than $MaxDate.")
                }
                $FileList += $OtherOldFiles
            }
        }

        $NbRemove = 0
        foreach ($File in $FileList)
        {
            if (-not $WhatIf) { Remove-Item $File.FullName }
            $NbRemove += 1
            Write-LogMessage ("`t`t`t File "+ $File.Name + " Removed.")
        }
        
        Write-LogMessage ("`t`t $NbRemove Files Removed for cleaning process.")
    }

function Start-ScriptBackup
{
    Param (
        $TargetPath,
        $ClearFilesOlderThan = 7
    )

    $Script:BackupPath = $TargetPath + "\Updater-AutoBackup"
    if (!(Test-Path $Script:BackupPath) -and -not $WhatIf) {New-Item -Path $Script:BackupPath -ItemType Directory | Out-Null}

    # remove all previous backup folders older than 7 days
    $MaxDate = (Get-Date).AddDays($ClearFilesOlderThan * -1)
    $BackupFolders = Get-ChildItem -Path $Script:BackupPath -Directory
    $BackupFolders = $BackupFolders | Where-Object {$_.LastWriteTime -le $MaxDate}
    foreach ($BackupFolder in $BackupFolders)
    {
        if (-not $WhatIf) { Remove-Item $BackupFolder.FullName -Recurse }
        else { Write-LogMessage "`t ..Backup folder $BackupFolder removed."}
    }

    $Script:CurrentBackupPath = $Script:BackupPath + "\Updater-" + (Get-Date -Format "yyyy-MM-dd_HH-mm-ss")
    if (-not $WhatIf) { New-Item -Path $Script:CurrentBackupPath -ItemType Directory | Out-Null }
    Write-LogMessage "`t ..Backup folder created at $Script:CurrentBackupPath"

    $Script:BackupPath = $Script:CurrentBackupPath

    # copy all files from the script folder to the backup folder
    $ScriptFiles = Get-ChildItem -Path $TargetPath -File
    foreach ($ScriptFile in $ScriptFiles)
    {
       if (-not $WhatIf) { Copy-Item -Path $ScriptFile.FullName -Destination $Script:BackupPath }
       else { Write-LogMessage "`t ..File $ScriptFile copied to backup folder." }
    }
    Write-LogMessage "`t ..Script files copied to backup folder."

    # copy all files from the config folder in Targetpath to the backup folder including subfolders
    $ConfigFiles = Get-ChildItem -Path "$TargetPath\Config" -Recurse -File -Include "*.json"
    $ConfigFiles += Get-ChildItem -Path "$TargetPath" -File -Include "*.json"
    foreach ($ConfigFile in $ConfigFiles)
    {
        $ConfigFileDestination = $Script:BackupPath + $ConfigFile.FullName.Substring($TargetPath.Length)
        # if the destination directory does not exist, create it
        if (!(Test-Path (Split-Path $ConfigFileDestination))) 
        {
            if (-not $WhatIf) { New-Item -Path (Split-Path $ConfigFileDestination) -ItemType Directory | Out-Null }
            else { Write-LogMessage "`t ..Folder $(Split-Path $ConfigFileDestination) created." }
        }
        if (-not $WhatIf) { Copy-Item -Path $ConfigFile.FullName -Destination $ConfigFileDestination }
        else { Write-LogMessage "`t ..File $ConfigFile copied to backup folder." }
    }

}

function Get-UDSLogs
{
    [CmdletBinding()]
    param()

    return $Script:UDSLogs
}

function CheckRecursive
{
    Param(
        $JsonSegment,
        $JsonTestSegment,
        $TestType,
        $Path = "Root",
        [switch] $ApplyUpdate
    )

    $memberlist = $JsonSegment | Get-Member -MemberType NoteProperty

    $ReturnObject = New-Object -TypeName PSObject
    $ReturnObject | Add-Member -MemberType NoteProperty -Name "Path" -Value $Path
    $ReturnObject | Add-Member -MemberType NoteProperty -Name "ErrorSubList" -Value @()
    $ReturnObject | Add-Member -MemberType NoteProperty -Name "ErrorInPath" -Value @()
    $ReturnObject | Add-Member -MemberType NoteProperty -Name "ErrorCount" -Value 0
    $ReturnObject | Add-Member -MemberType NoteProperty -Name "TotalList" -Value @()
    foreach ($attribMember in $memberlist)
    {
        if ($attribMember.Name -in @("AuditFunctions", "VersionInformation", "AuditFunctionsFiles", "AuditFunctionProtectedArea", "InstanceExample")) {continue;}
    
        $errorTest = $false
        if ($null -eq $JsonTestSegment.($attribMember.Name))
        {
            Write-Host "`tEntry $Path\$($attribMember.Name) is missing in $TestType Version of configuration" -ForegroundColor Yellow
            $MissingEntry = New-Object -TypeName PSObject
            $MissingEntry | Add-Member -MemberType NoteProperty -Name "Path" -Value $Path
            $MissingEntry | Add-Member -MemberType NoteProperty -Name "Entry" -Value $attribMember.Name
            $MissingEntry | Add-Member -MemberType NoteProperty -Name "EntryValue" -Value $JsonSegment.($attribMember.Name)
            $MissingEntry | Add-Member -MemberType NoteProperty -Name "ErrorMessage" -Value "`tEntry $Path\$($attribMember.Name) is missing in $TestType Version of configuration"
            $ReturnObject.ErrorInPath += $MissingEntry
            $ReturnObject.TotalList += $MissingEntry
            $ReturnObject.ErrorCount += 1
            $errorTest = $true

            if ($ApplyUpdate) { $JsonTestSegment | Add-Member NoteProperty -Name $attribMember.Name -Value $JsonSegment.($attribMember.Name) }
        }
        else {
            Write-Host "`tEntry $Path\$($attribMember.Name) exists in $TestType Version of configuration"
        }
        $subResult = $JsonSegment.($attribMember.Name)
        $subTestResult = $JsonTestSegment.($attribMember.Name)

        if (-not $errorTest -and $null -ne $subResult -and $attribMember.Definition.StartsWith("System.Management.Automation.PSCustomObject"))
        {
            $ReturnObject.ErrorSubList = CheckRecursive -JsonSegment $subResult -JsonTestSegment $subTestResult -TestType $TestType -Path ($Path + "\$($attribMember.Name)") -ApplyUpdate:$ApplyUpdate
            $ReturnObject.ErrorCount += $ReturnObject.ErrorSubList.ErrorCount
            $ReturnObject.TotalList += $ReturnObject.ErrorSubList.TotalList
        }
    }

    return $ReturnObject
}

function Update-AddonsFromInternetRepository
{
    Param (
        [switch] $Beta,
        $TargetPath,
        $Category = $null  
    )

    if (-not $Global:isRunbook )
    {
        # Verify the cache directory exists
        $ScriptAddonCachePath = $TargetPath + '\Config\Add-Ons\'
        $GithubSourcePath = "https://raw.githubusercontent.com/nlepagnez/ESI-PublicContent/main/Operations/ESICollector-Addons"

        if ($Beta)
        {
            $GithubSourcePath += "/Beta"
        }

        if ($null -ne $Category)
        {
            $ScriptAddonCachePath += "Categories\$($Category)\"
            $GithubSourcePath += "/Categories/$($Category)/"
        }

        Push-Location ($TargetPath);
        if (! (Test-Path $ScriptAddonCachePath)) 
        { 
            Write-LogMessage -Message "Configuration directory doesn't exist, Critital error" -Level Error
            return $null
        }
        
        $files = Get-ChildItem -Path $ScriptAddonCachePath -Filter "ESICollector-*.json" 
        if ($null -eq $files -or $files.count -le 0) 
        {
            Write-LogMessage -Message "No config file found in Config directory, New configuration files will be downloaded" -Level Error
            $DownloadConfiguration = $True
        }

        if (Test-Path ($ScriptAddonCachePath + "ESIChecksumFiles.json"))
        {
            $ChecksumContent = Get-Content ($ScriptAddonCachePath + "ESIChecksumFiles.json") | ConvertFrom-Json
            if ($ChecksumContent.Files.Count -ne $files.count)
            {
                Write-LogMessage -Message "Invalidate confguration because incoherence in number of files - Theory : $($ChecksumContent.Files.Count) / Real : $($files.count)" -Level Warning; 
                if (-not $WhatIf) { Get-ChildItem -Path $ScriptAddonCachePath | Remove-Item }
                else { Write-LogMessage -Message "WhatIf mode, no file will be removed - Tested file : $ScriptAddonCachePath" }
                $DownloadConfiguration = $True
            }
            else {
                foreach ($checksumfile in $ChecksumContent.Files)
                {
                    if ((Get-FileHash -Path ($ScriptAddonCachePath + $checksumfile.FileName) -Algorithm SHA256).Hash -ne $checksumfile.FileCheckSum)
                    {
                        Write-LogMessage -Message "Invalidate Configuration because cached file modified outside authorized method ($($checksumfile.FileName))" -Level Warning; 
                        if (-not $WhatIf) { Get-ChildItem -Path $ScriptAddonCachePath | Remove-Item }
                        else { Write-LogMessage -Message "WhatIf mode, no file will be removed - Tested file : $ScriptAddonCachePath"}
                        $DownloadConfiguration = $True
                        break;
                    }
                }
            }
        }
        else {
            Write-LogMessage -Message "Invalidate Configuration because ESIChecksumFiles.json not present" -Level Warning; 
            if (-not $WhatIf) { Get-ChildItem -Path $ScriptAddonCachePath | Remove-Item }
            else { Write-LogMessage -Message "WhatIf mode, no file will be removed - Tested file : $ScriptAddonCachePath"}
            $DownloadConfiguration = $True
        }

        # Retrieve File Checksum list
        
        try {
            if ($Useproxy)
            {
                $WebResult = invoke-WebRequest -Uri "$GithubSourcePath/ESIChecksumFiles.json" -UseBasicParsing -Proxy $Script:ProxyUrl
            }
            else
            {
                $WebResult = invoke-WebRequest -Uri "$GithubSourcePath/ESIChecksumFiles.json" -UseBasicParsing
            }
        }
        catch {
            Write-LogMessage -Message "Impossible to retrieve files from Online Github. Error : $($_.Exception)" -Level Warning; 
            return $null
        }
        
        $localHash = Get-FileHash -Path $ScriptAddonCachePath + "ESIChecksumFiles.json" -Algorithm SHA256

        $stringAsStream = [System.IO.MemoryStream]::new()
        $writer = [System.IO.StreamWriter]::new($stringAsStream)
        $writer.write($WebResult.Content)
        $writer.Flush()
        $stringAsStream.Position = 0
        $onlineHash = Get-FileHash -InputStream $stringAsStream -Algorithm SHA256

        if ($localHash.Hash -ne $onlineHash.Hash)
        {
            Write-LogMessage -Message "New online content. Cache invalidation to update content"; 
            if (-not $WhatIf) { Get-ChildItem -Path $ScriptAddonCachePath | Remove-Item }
            else {
                Write-LogMessage -Message "WhatIf mode, no file will be removed - Tested file : $ScriptAddonCachePath"
            }
            $DownloadConfiguration = $True
        }

        if ($DownloadConfiguration) 
        {
            Write-LogMessage -Message "Update Cache Content"; 
           if (-not $WhatIf) { $WebResult.Content | Set-Content -Path ($ScriptAddonCachePath + "ESIChecksumFiles.json") }
            else { Write-LogMessage -Message "WhatIf mode, no file will be created - Tested file : $ScriptAddonCachePath ESIChecksumFiles.json" }
            $OnlineFiles = $WebResult.Content | ConvertFrom-Json

            # Add all file in the list
            foreach ($OnlineFile in $OnlineFiles.Files)
            {
                $uri = "$GithubSourcePath/$($OnlineFile.FileName)"
                try {
                    if ($Useproxy)
                    {
                        $WebResult = invoke-WebRequest -Uri $uri -UseBasicParsing -Proxy $Script:ProxyUrl
                    }
                    else
                    {
                        $WebResult = invoke-WebRequest -Uri $uri -UseBasicParsing
                    }
                }
                catch {
                    Write-LogMessage -Message "Impossible to retrieve file $($OnlineFile.FileName) from Online Github. Error : $($_.Exception)" -Level Warning; 
                }
                if (-not $WhatIf) { $WebResult.Content | Set-Content -Path ($ScriptAddonCachePath + $OnlineFile.FileName) }
                else { Write-LogMessage -Message "WhatIf mode, no file will be created - Tested file : $ScriptAddonCachePath$($OnlineFile.FileName)" }
            }
        }
        else {
            Write-LogMessage -Message "Configuration is up to date without any update needed"; 
        }
    }
    else {
        Write-LogMessage -Message "Runbook mode, no need to update configuration, directly downloaded from Github";
    }
}

function Start-AddonsDownload
{
    Param (
        [switch] $Beta,
        $SourcePath,
        $TargetPath,
        $Category = $null
    )

    if (-not $Global:isRunbook )
    {
        # Verify the cache directory exists
        $ScriptAddonCachePath = $TargetPath + '\Config\Add-Ons\'
        $GithubSourcePath = "https://raw.githubusercontent.com/nlepagnez/ESI-PublicContent/main/Operations/ESICollector-Addons"

        if ($Beta)
        {
            $GithubSourcePath += "/Beta"
        }

        if ($null -ne $Category)
        {
            $ScriptAddonCachePath += "Categories\$($Category)\"
            $GithubSourcePath += "/Categories/$($Category)"
        }

        Push-Location ($SourcePath)
        
        if (! (Test-Path $ScriptAddonCachePath)) 
        { 
            if (-not $WhatIf) { mkdir $ScriptAddonCachePath -Force | Out-Null }
            else { Write-LogMessage -Message "WhatIf mode, no directory will be created - Tested directory : $ScriptAddonCachePath" }
        }
                
        Write-LogMessage -Message "Update Cache Content"; 
        try {
            if ($Useproxy)
            {
                $WebResult = invoke-WebRequest -Uri "$GithubSourcePath/ESIChecksumFiles.json" -UseBasicParsing -Proxy $Script:ProxyUrl
            }
            else
            {
                $WebResult = invoke-WebRequest -Uri "$GithubSourcePath/ESIChecksumFiles.json" -UseBasicParsing
            }
        }
        catch {
            Write-LogMessage -Message "Impossible to retrieve files from Online Github. Error : $($_.Exception)" -NoOutput -Level Warning; 
            return $null
        }

        if (-not $WhatIf) { $WebResult.Content | Set-Content -Path ($ScriptAddonCachePath + "ESIChecksumFiles.json") }
        else { Write-LogMessage -Message "WhatIf mode, no file will be created - Tested file : $ScriptAddonCachePath ESIChecksumFiles.json" }
        
        $OnlineFiles = $WebResult.Content | ConvertFrom-Json

        # Add all file in the list
        foreach ($OnlineFile in $OnlineFiles.Files)
        {
            $uri = "$GithubSourcePath/$($OnlineFile.FileName)"
            try {
                if ($Useproxy)
                {
                    $WebResult = invoke-WebRequest -Uri $uri -UseBasicParsing -Proxy $Script:ProxyUrl
                }
                else
                {
                    $WebResult = invoke-WebRequest -Uri $uri -UseBasicParsing
                }
            }
            catch {
                Write-LogMessage -Message "Impossible to retrieve file $($OnlineFile.FileName) from Online Github. Error : $($_.Exception)" -Level Warning; 
            }
            if (-not $WhatIf) { $WebResult.Content | Set-Content -Path ($ScriptAddonCachePath + $OnlineFile.FileName) }
            else { Write-LogMessage -Message "WhatIf mode, no file will be created - Tested file : $ScriptAddonCachePath$($OnlineFile.FileName)" }
        }
    }
    else {
        Write-LogMessage -Message "Runbook mode, no need to update configuration, directly downloaded from Github";
    }
}

function Update-AddonsOfflineMode
{
    Param (
        [switch] $Beta,
        $SourcePath,
        $TargetPath,
        $Category = $null  
    )

    if (-not $Global:isRunbook )
    {
        # Verify the cache directory exists
        $ScriptAddonCachePath = $TargetPath + '\Config\Add-Ons\'
        $GithubSourcePath = $SourcePath + '\Config\Add-Ons\'

        if ($null -ne $Category)
        {
            $ScriptAddonCachePath += "Categories\$($Category)\"
            $GithubSourcePath += "\Categories\$($Category)"
        }

        Push-Location ($TargetPath);
        if (! (Test-Path $ScriptAddonCachePath)) 
        { 
            Write-LogMessage -Message "Configuration directory doesn't exist, Critital error" -Level Error
            return $null
        }
        
        $files = Get-ChildItem -Path $ScriptAddonCachePath -Filter "ESICollector-*.json" 
        if ($null -eq $files -or $files.count -le 0) 
        {
            Write-LogMessage -Message "No config file found in Config directory, New configuration files will be downloaded" -Level Error
            $DownloadConfiguration = $True
        }

        if (Test-Path ($ScriptAddonCachePath + "ESIChecksumFiles.json"))
        {
            $ChecksumContent = Get-Content ($ScriptAddonCachePath + "ESIChecksumFiles.json") | ConvertFrom-Json
            if ($ChecksumContent.Files.Count -ne $files.count)
            {
                Write-LogMessage -Message "Invalidate confguration because incoherence in number of files - Theory : $($ChecksumContent.Files.Count) / Real : $($files.count)" -Level Warning; 
                if (-not $WhatIf) { Get-ChildItem -Path $ScriptAddonCachePath | Remove-Item }
                else { Write-LogMessage -Message "WhatIf mode, no file will be removed - Tested file : $ScriptAddonCachePath" }
                
                $DownloadConfiguration = $True
            }
            else {
                foreach ($checksumfile in $ChecksumContent.Files)
                {
                    if ((Get-FileHash -Path ($ScriptAddonCachePath + $checksumfile.FileName) -Algorithm SHA256).Hash -ne $checksumfile.FileCheckSum)
                    {
                        Write-LogMessage -Message "Invalidate Configuration because cached file modified outside authorized method ($($checksumfile.FileName))" -Level Warning; 
                        if (-not $WhatIf) { Get-ChildItem -Path $ScriptAddonCachePath | Remove-Item }
                        else { Write-LogMessage -Message "WhatIf mode, no file will be removed - Tested file : $ScriptAddonCachePath" }
                        
                        $DownloadConfiguration = $True
                        break;
                    }
                }
            }
        }
        else {
            Write-LogMessage -Message "Invalidate Configuration because ESIChecksumFiles.json not present" -Level Warning; 
            
            if (-not $WhatIf) { Get-ChildItem -Path $ScriptAddonCachePath | Remove-Item }
            else { Write-LogMessage -Message "WhatIf mode, no file will be removed - Tested file : $ScriptAddonCachePath" }
                
            $DownloadConfiguration = $True
        }

        # Retrieve File Checksum list
        
        try {
            $WebResult = Get-Content -Path ($GithubSourcePath + "\ESIChecksumFiles.json")
        }
        catch {
            Write-LogMessage -Message "Impossible to retrieve files from Online Github. Error : $($_.Exception)" -Level Warning; 
            return $null
        }
        
        $localHash = Get-FileHash -Path $ScriptAddonCachePath + "ESIChecksumFiles.json" -Algorithm SHA256

        $stringAsStream = [System.IO.MemoryStream]::new()
        $writer = [System.IO.StreamWriter]::new($stringAsStream)
        $writer.write($WebResult)
        $writer.Flush()
        $stringAsStream.Position = 0
        $onlineHash = Get-FileHash -InputStream $stringAsStream -Algorithm SHA256

        if ($localHash.Hash -ne $onlineHash.Hash)
        {
            Write-LogMessage -Message "New online content. Cache invalidation to update content"; 
            
            if (-not $WhatIf) { Get-ChildItem -Path $ScriptAddonCachePath | Remove-Item }
            else { Write-LogMessage -Message "WhatIf mode, no file will be removed - Tested file : $ScriptAddonCachePath" }
                
            $DownloadConfiguration = $True
        }

        if ($DownloadConfiguration) 
        {
            Write-LogMessage -Message "Update Cache Content"; 
            $WebResult | Set-Content -Path ($ScriptAddonCachePath + "ESIChecksumFiles.json")
            $OnlineFiles = $WebResult | ConvertFrom-Json

            # Add all file in the list
            foreach ($OnlineFile in $OnlineFiles.Files)
            {
                $uri = "$GithubSourcePath\$($OnlineFile.FileName)"
                try {
                    $WebResult = Get-Content -Path $uri -ErrorAction Stop
                }
                catch {
                    Write-LogMessage -Message "Impossible to retrieve file $($OnlineFile.FileName) from Source Download path. Error : $($_.Exception)" -Level Warning; 
                }
                if (-not $WhatIf) { $WebResult | Set-Content -Path ($ScriptAddonCachePath + $OnlineFile.FileName) }
                else { Write-LogMessage -Message "WhatIf mode, no file will be created - Tested file : $ScriptAddonCachePath$($OnlineFile.FileName)" }
            }
        }
        else {
            Write-LogMessage -Message "Configuration is up to date without any update needed"; 
        }
    }
    else {
        Write-LogMessage -Message "Runbook mode, no need to update configuration, directly downloaded from Github";
    }
}

function Invoke-AzureAutomationCmd
{
    Param(
        $Body,
        $Runbook
    )
    
    if ($null -eq $Script:AccessToken)
    {
        Write-LogMessage -Message ("Connect to Management Azure RestAPI ...")
        Write-LogMessage -Message "Connect to Azure RM"

        if (-not $Global:AlreadyAzConnected)
        {
            # Ensures you do not inherit an AzContext in your runbook
            Disable-AzContextAutosave -Scope Process
            
            if ($isRunbook)
            {
                # Connect to Azure with system-assigned managed identity
                $AzureContext = (Connect-AzAccount -Identity).context
            }
            else {
                if ($Global:Interactive)
                {
                    Write-LogMessage -Message "Az Connect with Interactive Logon"
                    $AzureContext = (Connect-AzAccount).context
                }
                else {
                    Write-LogMessage -Message "Az Connect with Interactive Logon"
                    $AzureContext = (Connect-AzAccount -CertificateThumbprint $Script:MGGraphAzureRMCertificate -Tenant $Script:TenantName -ApplicationId $Script:MGGraphAzureRMAppId).context
                }
            }
            $Global:AlreadyAzConnected = $true
        }
        else {$AzureContext = Get-AzContext}

        $context = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile.DefaultContext

        $Script:AccessToken = [Microsoft.Azure.Commands.Common.Authentication.AzureSession]::Instance.AuthenticationFactory.Authenticate($context.Account, $context.Environment, $context.Tenant.Id.ToString(), $null, [Microsoft.Azure.Commands.Common.Authentication.ShowDialog]::Never, $null, "https://management.azure.com/")

    }

    try {
    
        # Draft
        $headerParams = @{'Authorization'="Bearer $($script:AccessToken.AccessToken)"}
        $url="https://management.azure.com/subscriptions/$($script:SubscriptionId)/resourceGroups/$($script:resourceGroup)/providers/Microsoft.Automation/automationAccounts/$($script:automationAccountName)/runbooks/$Runbook/draft/content?api-version=2019-06-01"
        
        if (-not $whatif) { 
            $results=Invoke-RestMethod -Uri $url -Headers $headerParams -Method Put -Body $body
            Write-Output $results.value
        }
        else {
            Write-LogMessage -Message "WhatIf mode, Simulate Put request to $url with body $body"
        }


        # Publish
        $url="https://management.azure.com/subscriptions/$($script:SubscriptionId)/resourceGroups/$($script:resourceGroup)/providers/Microsoft.Automation/automationAccounts/$($script:automationAccountName)/runbooks/$Runbook/publish?api-version=2019-06-01"
        
        if (-not $whatif) { $results=Invoke-RestMethod -Uri $url -Headers $headerParams -Method POST }
        else { Write-LogMessage -Message "WhatIf mode, Simulate Post request to $url" }
    
    }
    catch {
        Write-LogMessage -Message "Error while publishing runbook $Runbook. Error : $($_.Exception)" -Level Warning; 
    }

}

function Get-AzureAutomationRunbook
{
    Param(
        $Runbook
    )
    
    if ($null -eq $Script:AccessToken)
    {
        Write-LogMessage -Message ("Connect to Management Azure RestAPI ...")
        Write-LogMessage -Message "Connect to Azure RM"

        if (-not $Global:AlreadyAzConnected)
        {
            # Ensures you do not inherit an AzContext in your runbook
            Disable-AzContextAutosave -Scope Process | out-null
            
            if ($isRunbook)
            {
                # Connect to Azure with system-assigned managed identity
                $AzureContext = (Connect-AzAccount -Identity).context
            }
            else {
                if ($Global:Interactive)
                {
                    Write-LogMessage -Message "Az Connect with Interactive Logon"
                    $AzureContext = (Connect-AzAccount).context
                }
                else {
                    Write-LogMessage -Message "Az Connect with Interactive Logon"
                    $AzureContext = (Connect-AzAccount -CertificateThumbprint $Script:MGGraphAzureRMCertificate -Tenant $Script:TenantName -ApplicationId $Script:MGGraphAzureRMAppId).context
                }
            }
            $Global:AlreadyAzConnected = $true
        }
        else {$AzureContext = Get-AzContext}

        $context = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile.DefaultContext

        $Script:AccessToken = [Microsoft.Azure.Commands.Common.Authentication.AzureSession]::Instance.AuthenticationFactory.Authenticate($context.Account, $context.Environment, $context.Tenant.Id.ToString(), $null, [Microsoft.Azure.Commands.Common.Authentication.ShowDialog]::Never, $null, "https://management.azure.com/")

    }

    try {
    
        $headerParams = @{'Authorization'="Bearer $($script:AccessToken.AccessToken)"}
        $url="https://management.azure.com/subscriptions/$($script:SubscriptionId)/resourceGroups/$($script:resourceGroup)/providers/Microsoft.Automation/automationAccounts/$($script:automationAccountName)/runbooks/$Runbook/content?api-version=2019-06-01"
        Write-LogMessage -Message "Get to URL $url "
        $results=Invoke-RestMethod -Uri $url -Headers $headerParams -Method GET

        return $results
    
    }
    catch {
        Write-LogMessage -Message "Error while publishing runbook $Runbook. Error : $($_.Exception)" -Level Warning; 
    }

}

function Invoke-ESIWebRequest
{
    Param(
        $Uri
    )

    $object = $null

    if ($script:Useproxy)
    {
        $object = (Invoke-WebRequest -Uri $Uri -UseBasicParsing -Proxy $Script:ProxyUrl).Content
    }
    else
    {
        $object = (Invoke-WebRequest -Uri $Uri -UseBasicParsing).Content
    }

    return $object
}

function Get-VersionTrackingFromOnline
{
    try {
        
        if ($BetaVersion)
        {
            $VersionTracking = Invoke-ESIWebRequest -Uri "https://aka.ms/BetaESICollectorVersionTracking"
        }
        else {
            $VersionTracking = Invoke-ESIWebRequest -Uri "https://aka.ms/ESICollectorVersionTracking"
        }
    }
    catch {
        Write-LogMessage "Unable to get version tracking file from https://aka.ms/ESICollectorVersionTracking. Exception $($_.Exception); Fatal Error" -Level Error
        return $null
    }

    $VersionTracking = $VersionTracking | ConvertFrom-Json

    return $VersionTracking
}

function Update-ScriptFromInternet
{
    Param(
        [Parameter(Mandatory=$false)] [string] $TargetPath,
        [Parameter(Mandatory=$false)] [string] $SpecificTargetVersion,
        [Parameter(Mandatory=$false)] [int] $InternalSpecificVersion,
        [Parameter(Mandatory=$true)] [int] $InternalVersionCurentFile,
        [Parameter(Mandatory=$True)] [string] $CurrentVersion,
        [switch] $DownloadOnly,
        [switch] $ForceUpdate
    )
    
    $VersionTracking = Get-VersionTrackingFromOnline

    if (-not [string]::IsNullOrEmpty($SpecificTargetVersion)) {
        $TargetVersion = $VersionTracking.VersionHistory | Where-Object { $_.Version -eq $SpecificTargetVersion }
        if ($Script:VersionRollback)
        {
            $VersionUpgradePath = $VersionTracking.VersionHistory | Where-Object { $_.InternalVersion -ge $InternalSpecificVersion -and $_.InternalVersion -lt $InternalVersionCurentFile }
        }
        else
        {
            $VersionUpgradePath = $VersionTracking.VersionHistory | Where-Object { $_.InternalVersion -le $InternalSpecificVersion -and $_.InternalVersion -gt $InternalVersionCurentFile }
        }

        if ([string]::IsNullOrEmpty($TargetVersion)) {
            Write-LogMessage "Unable to find the requested version $SpecificTargetVersion in the version tracking file, this version doesn't exist. Please check the version number and try again" -Level Error
            exit
        }
    }
    else {
        [int] $InternalTargetVersion = $VersionTracking.LatestVersion -replace "\.",""
        $TargetVersion = $VersionTracking.VersionHistory | Where-Object { $_.Version -eq $VersionTracking.LatestVersion }

        if ($InternalTargetVersion -gt $InternalVersionCurentFile) {
            $VersionUpgradePath = $VersionTracking.VersionHistory | Where-Object { $_.InternalVersion -gt $InternalVersionCurentFile }
        }
        else {
            Write-LogMessage "No update available, current version is $CurrentVersion, latest version is $($VersionTracking.LatestVersion)" -Level Warning
            if ($ForceUpdate) {
                Write-LogMessage "ForceUpdate switch is used, current file will be rewritten with original file" -Level Warning
                $VersionUpgradePath = $VersionTracking.VersionHistory | Where-Object { $_.InternalVersion -gt $InternalVersionCurentFile }
            }
            else {
                return
            }
        }
    }

    if (-not $DownloadOnly) {

        # for each version in VersionUpgradePath, verify that there is BreakingChanges and add it in the $BreakingChanges table variable if the Target is equal to 'On-Premises' or 'All'
        $BreakingChanges = @()
        foreach ($Version in $VersionUpgradePath) {
            if ($null -ne $Version.BreakingChanges) {
                foreach ($BreakingChange in $Version.BreakingChanges) {
                    if ($BreakingChange.Target -eq "On-Premises" -or $BreakingChange.Target -eq "All") {
                        $BreakingChanges += $BreakingChange
                    }
                }
            }
        }

        if ($BreakingChanges.Count -gt 0) {
            Write-LogMessage "The following Breaking Changes could be applied only if 'ForceUpdate' switch is used as those changes need manual configuration/changes :"
            foreach ($BreakingChange in $BreakingChanges) {
                Write-LogMessage "    $($BreakingChange.Description)"
            }

            if ($ForceUpdate) {
                Write-LogMessage "ForceUpdate switch was used, the Collector will be updated"
            }
            else {
                Write-LogMessage "ForceUpdate switch was not used, the Collector will not be updated"
                return
            }
        }
    }
    else {
        #Write the VersionTracking file in the target folder
        if (-not $WhatIf) { $VersionTracking | ConvertTo-Json | Out-File "$TargetPath\ESICollectorVersionTracking.json" -Force }
        else { Write-LogMessage "WhatIf mode, no file will be created - Tested file : $TargetPath\ESICollectorVersionTracking.json" }
    }

    Write-LogMessage "Target version is $($TargetVersion.Version)"
        
    if ($TargetVersion.Beta)
    {
        $SourcePath = "$($VersionTracking.ESICollectorRawRepository)/Beta/$($TargetVersion.VersionFileName)"
    }
    else 
    { 
        $SourcePath = "$($VersionTracking.ESICollectorRawRepository)/$($TargetVersion.VersionFileName)"
    }

    # Download the file
    try {
        $DownloadedFile = Invoke-ESIWebRequest -Uri $SourcePath
    }
    catch {
        Write-LogMessage "Unable to download the file $SourcePath. Exception $($_.Exception); Fatal Error" -Level Error
        exit
    }

    $script:ConfigurationTargetVersion = $null

    if ($Global:isRunbook) {
        $DownloadedFile = [System.IO.MemoryStream]::new($DownloadedFile)
        $ZipFile = [System.IO.Compression.ZipArchive]::new($DownloadedFile)
        $files = $ZipFile.Entries | Where-Object { $_.Name -in ("CollectExchSecIns.ps1","Updater.ps1","CollectExchSecConfiguration.json") }
        $files | ForEach-Object {
            $File = $_
            $FileContent = $File.Open()

            switch ($File.Name) {
                "CollectExchSecIns.ps1" {
                    Invoke-AzureAutomationCmd -Body $FileContent -Runbook "Start-ESICollector"
                }
                "Updater.ps1" {
                    Invoke-AzureAutomationCmd -Body $FileContent -Runbook "Updater"
                }
                "CollectExchSecConfiguration.json" {
                    # extract filestream to string
                    $StreamReader = [System.IO.StreamReader]::new($FileContent)
                    $script:ConfigurationTargetVersion = $StreamReader.ReadToEnd()
                    $StreamReader.Close()

                    $script:ConfigurationTargetVersion = $ConfigurationTargetVersion | ConvertFrom-Json
                }
            }

            $FileContent.Close()
        }

        $ZipFile.Dispose()
    }
    else {
        # Extract the PowerShell script from the downloaded zip file

        $FileListToCopy = @("CollectExchSecIns.ps1","setup.ps1","Updater.ps1","CollectExchSecConfiguration.json")
        
        try {
            $DownloadedFile = [System.IO.MemoryStream]::new($DownloadedFile)
            $ZipFile = [System.IO.Compression.ZipArchive]::new($DownloadedFile)
            $files = $ZipFile.Entries | Where-Object { $_.Name -in $FileListToCopy }
            $files | ForEach-Object {
                $File = $_
                $FileContent = $File.Open()
                if ("CollectExchSecConfiguration.json" -eq $File.Name) {
                    if ($DownloadOnly) {
                        if (-not $Whatif) { $FileContent.CopyTo([System.IO.File]::Create("$TargetPath\CollectExchSecConfiguration-ForNewVersion.json")) }
                        else { Write-LogMessage "WhatIf mode, no file will be created - Tested file : $TargetPath\CollectExchSecConfiguration-ForNewVersion.json" }
                    }
                    else {
                        # extract filestream to string
                        $StreamReader = [System.IO.StreamReader]::new($FileContent)
                        $script:ConfigurationTargetVersion = $StreamReader.ReadToEnd()
                        $StreamReader.Close()

                        $script:ConfigurationTargetVersion = $ConfigurationTargetVersion | ConvertFrom-Json
                    }
                }
                else 
                { 
                    if (-not $WhatIf) { $FileContent.CopyTo([System.IO.File]::Create("$TargetPath\$($File.Name)")) }
                    else { Write-LogMessage "WhatIf mode, no file will be created - Tested file : $TargetPath\$($File.Name)" }
                }
                $FileContent.Close()
            }

            $ZipFile.Dispose()
        }
        catch {
            Write-LogMessage "Unable to extract the PowerShell script from the downloaded zip file. Exception $($_.Exception); Fatal Error" -Level Error
            return
        }
    }

    if ($DownloadOnly) {
        $Script:EndMessage += "Download only mode, the Collector was downloaded to the folder $TargetPath to version $($TargetVersion.Version)"
    }
    else {
        $Script:EndMessage += "The Collector was updated to the folder $TargetPath to version $($TargetVersion.Version)."
    }
}

function Update-ScriptOfflineMode
{
    Param(
        [Parameter(Mandatory=$True)] [string] $SourcePath,
        [Parameter(Mandatory=$True)] [string] $TargetPath,
        [Parameter(Mandatory=$True)] [string] $CurrentVersion,
        [Parameter(Mandatory=$False)] [string] $SpecificTargetVersion,
        [Parameter(Mandatory=$false)] [int] $InternalSpecificVersion,
        [Parameter(Mandatory=$False)] [switch] $ForceUpdate,
        [Parameter(Mandatory=$true)] [int] $InternalVersionCurentFile

    )
    
    if (Test-Path $SourcePath)
    {
        Write-LogMessage "Offline update mode, the Collector will be updated from the Folder $SourcePath"
        if (-not (Test-Path ($SourcePath + "\CollectExchSecIns.ps1")))
        {
            Write-LogMessage "Offline update mode, the file $SourcePath\CollectExchSecIns.ps1 was not found. Please check the path and try again" -Level Error
            exit
        }
        else {
            $SpecificTargetVersion = (Get-Content ($SourcePath + "\CollectExchSecIns.ps1") | Select-String -Pattern "ESICollectorCurrentVersion = " -SimpleMatch).ToString().Split("=")[1].Trim().Replace('"','')
            [int] $InternalSpecificVersion = $SpecificTargetVersion -replace "\.",""
            if ($InternalSpecificVersion -lt 1000) {
                $InternalSpecificVersion = $InternalSpecificVersion * 10
                $SpecificTargetVersion += ".0"
            }
            Write-LogMessage "Target version is $SpecificTargetVersion"

            if ($InternalSpecificVersion -lt $InternalVersionCurentFile) {
                if ($ForceUpdate) {
                    Write-LogMessage "Current Version of the collector is greater than the requested SpecificTargetVersion $SpecificTargetVersion. ForceUpdate switch was used, the Collector will be replaced by the requested old version" -Level Warning
                    $Script:VersionRollback = $true
                }
                else {
                    Write-LogMessage "Current Version of the collector is greater than the requested SpecificTargetVersion $SpecificTargetVersion. Rollback is forbidden without 'ForceUpdate' switch" -Level Error
                    exit
                }
            }
        }

        if (-not (Test-Path ($SourcePath + "\Updater.ps1")))
        {
            Write-LogMessage "Offline update mode, the file $SourcePath\Updater.ps1 was not found. Please check the path and try again" -Level Error
            exit
        }

        if (-not (Test-Path ($SourcePath + "\setup.ps1")))
        {
            Write-LogMessage "Offline update mode, the file $SourcePath\setup.ps1 was not found. Please check the path and try again" -Level Error
            exit
        }

        if (-not (Test-Path ($SourcePath + "\ESICollectorVersionTracking.json")))
        {
            Write-LogMessage "Offline update mode, the file $SourcePath\ESICollectorVersionTracking.json was not found. Please check the path and try again" -Level Error
            exit
        }
    }
    else
    {
        Write-LogMessage "Offline update mode, the file $SourcePath was not found. Please check the path and try again" -Level Error
        exit
    }

    # load json file to get the version
    $VersionTracking = Get-Content "$SourcePath\ESICollectorVersionTracking.json" | ConvertFrom-Json
    
    $TargetVersion = $VersionTracking.VersionHistory | Where-Object { $_.Version -eq $SpecificTargetVersion }
    if ($Script:VersionRollback)
    {
        $VersionUpgradePath = $VersionTracking.VersionHistory | Where-Object { $_.InternalVersion -ge $InternalSpecificVersion -and $_.InternalVersion -lt $InternalVersionCurentFile }
    }
    else
    {
        $VersionUpgradePath = $VersionTracking.VersionHistory | Where-Object { $_.InternalVersion -le $InternalSpecificVersion -and $_.InternalVersion -gt $InternalVersionCurentFile }
    }

    if ([string]::IsNullOrEmpty($TargetVersion)) {
        Write-LogMessage "Unable to find the requested version $SpecificTargetVersion in the version tracking file. Please check the version number and try again" -Level Error
        exit
    }

    # for each version in VersionUpgradePath, verify that there is BreakingChanges and add it in the $BreakingChanges table variable if the Target is equal to 'On-Premises' or 'All'
    $BreakingChanges = @()
    foreach ($Version in $VersionUpgradePath) {
        if ($null -ne $Version.BreakingChanges) {
            foreach ($BreakingChange in $Version.BreakingChanges) {
                if ($BreakingChange.Target -eq "On-Premises" -or $BreakingChange.Target -eq "All") {
                    $BreakingChanges += $BreakingChange
                }
            }
        }
    }

    if ($BreakingChanges.Count -gt 0) {
        Write-LogMessage "The following Breaking Changes could be applied only if 'ForceUpdate' switch is used as those changes need manual configuration/changes :"
        foreach ($BreakingChange in $BreakingChanges) {
            Write-LogMessage "    $($BreakingChange.Description)"
        }

        if ($ForceUpdate) {
            Write-LogMessage "ForceUpdate switch was used, the Collector will be updated"
        }
        else {
            Write-LogMessage "ForceUpdate switch was not used, the Collector will not be updated"
            exit
        }
    }

    # try to copy files from sourcePath to targetPath
    try {
        if (-not $WhatIf)
        {
            Copy-Item -Path "$SourcePath\CollectExchSecIns.ps1" -Destination "$TargetPath\CollectExchSecIns.ps1" -Force
            Copy-Item -Path "$SourcePath\Updater.ps1" -Destination "$TargetPath\Updater.ps1" -Force
            Copy-Item -Path "$SourcePath\setup.ps1" -Destination "$TargetPath\setup.ps1" -Force
        }
        else {
            Write-LogMessage "WhatIf mode, no file will be created - Tested file : $TargetPath\CollectExchSecIns.ps1"
            Write-LogMessage "WhatIf mode, no file will be created - Tested file : $TargetPath\Updater.ps1"
            Write-LogMessage "WhatIf mode, no file will be created - Tested file : $TargetPath\setup.ps1"
        }
    }
    catch {
        Write-LogMessage "Unable to copy the files from $SourcePath to $TargetPath. Exception $($_.Exception); Fatal Error" -Level Error
        exit
    }

    # Create a directory 'Done' in SourcePath and move the files in it
    try {
        if (-not $WhatIf) { New-Item -Path "$SourcePath\Done" -ItemType Directory -Force }
        else { Write-LogMessage "WhatIf mode, no directory will be created - Tested directory : $SourcePath\Done" }

        # Create a directory with the date as suffix
        $Date = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
        if (-not $WhatIf) { New-Item -Path "$SourcePath\Done\$Date" -ItemType Directory -Force }
        else { Write-LogMessage "WhatIf mode, no directory will be created - Tested directory : $SourcePath\Done\$Date" }
        $Script:TargetMove = "$SourcePath\Done\$Date"

        if (-not $WhatIf) { 
            Move-Item -Path "$SourcePath\CollectExchSecIns.ps1" -Destination "$TargetMove\CollectExchSecIns.ps1" -Force
            Move-Item -Path "$SourcePath\Updater.ps1" -Destination "$TargetMove\Updater.ps1" -Force
            Move-Item -Path "$SourcePath\setup.ps1" -Destination "$TargetMove\setup.ps1" -Force
            Move-Item -Path "$SourcePath\ESICollectorVersionTracking.json" -Destination "$TargetMove\ESICollectorVersionTracking.json" -Force
        }
        else {
            Write-LogMessage "WhatIf mode, no file will be moved - Tested file : $SourcePath\CollectExchSecIns.ps1"
            Write-LogMessage "WhatIf mode, no file will be moved - Tested file : $SourcePath\Updater.ps1"
            Write-LogMessage "WhatIf mode, no file will be moved - Tested file : $SourcePath\setup.ps1"
            Write-LogMessage "WhatIf mode, no file will be moved - Tested file : $SourcePath\ESICollectorVersionTracking.json"
        }
    }
    catch {
        Write-LogMessage "Unable to create the directory $TargetMove or move the files in it. Exception $($_.Exception); Fatal Error" -Level Error
    }

    $Script:EndMessage += "The Collector was updated to the folder $TargetPath to version $($TargetVersion.Version)."
}

function Get-CurrentVersionOfScript
{
    Param(
        [string] $TargetPath
    )

    $Script:CurrentVersion = "0.0"
    $Script:InternalVersionCurentFile = 0

    if (-not $DownloadOnly)
    {
        if ($Global:isRunbook) {
            
            try {
                $Script:CurrentVersion =([regex]::Match($script:RunbookContent,"ESICollectorCurrentVersion = `"(?<Version>[0-9.]*)`"")).Groups["Version"].Value
                Write-LogMessage "Current version is $($Script:CurrentVersion)"
            }
            catch {
                $Script:CurrentVersion = "0.0"
                Write-LogMessage "Current version was not found on the Runbook Start-ESICollector, Regex no result"
            }
            <#if (($script:RunbookContent -match "ESICollectorCurrentVersion = `"(?<Version>[0-9.]*)`""))
            {
                $Script:CurrentVersion = $Matches.Version
                Write-LogMessage "Current version is $($Script:CurrentVersion)"
            }
            else {
                $Script:CurrentVersion = "0.0"
                Write-LogMessage "Current version was not found on the Runbook Start-ESICollector, file not found"
            }#>
            

            if ([string]::IsNullOrEmpty($CurrentVersion))
            {
                $Script:CurrentVersion = "0.0"
                Write-LogMessage "Current version was not found on the Runbook Start-ESICollector, file not found"
            }

            [int] $Script:InternalVersionCurentFile = $CurrentVersion -replace "\.",""
            if ($InternalVersionCurentFile -lt 1000) {
                $Script:InternalVersionCurentFile = $InternalVersionCurentFile * 10
            }
        }
        else {
            # Verify Current version
            if (Test-Path ($TargetPath + "\CollectExchSecIns.ps1"))
            {
                $Script:CurrentVersion = (Get-Content ($TargetPath + "\CollectExchSecIns.ps1") | Select-String -Pattern "ESICollectorCurrentVersion = " -SimpleMatch).ToString().Split("=")[1].Trim().Replace('"','')
                Write-LogMessage "Current version is $CurrentVersion"

                if ([string]::IsNullOrEmpty($CurrentVersion))
                {
                    $Script:CurrentVersion = "0.0"
                    Write-LogMessage "Current version was not found on the file $TargetPath\CollectExchSecIns.ps1, file not found"
                }
            }
            else
            {
                $Script:CurrentVersion = "0.0"
                Write-LogMessage "Current version was not found on the file $TargetPath\CollectExchSecIns.ps1, file not found"
            }

            [int] $Script:InternalVersionCurentFile = $CurrentVersion -replace "\.",""
            if ($InternalVersionCurentFile -lt 1000) {
                $Script:InternalVersionCurentFile = $InternalVersionCurentFile * 10
            }
        }
    }

    if (-not [string]::IsNullOrEmpty($SpecificTargetVersion)) {
        [int] $InternalSpecificVersion = $SpecificTargetVersion -replace "\.",""
        if (([string]$InternalSpecificVersion).length -ne 4) {
            Write-LogMessage "SpecificTargetVersion parameter is not valid, please use the format X.X.X.X" -Level Error
            exit
        }
    
        if ($InternalSpecificVersion -lt $InternalVersionCurentFile) {
            if ($ForceUpdate) {
                Write-LogMessage "Current Version of the collector is greater than the requested SpecificTargetVersion $SpecificTargetVersion. ForceUpdate switch was used, the Collector will be replaced by the requested old version" -Level Warning
                $Script:VersionRollback = $true
            }
            else {
                Write-LogMessage "Current Version of the collector is greater than the requested SpecificTargetVersion $SpecificTargetVersion. Rollback is forbidden without 'ForceUpdate' switch" -Level Error
                exit
            }
        }
    }

    $Script:CurrentVersion = $CurrentVersion
    $Script:InternalVersionCurentFile = $InternalVersionCurentFile
}


function CheckConfigurationFile
{
    Param(
        $ConfigurationCurrentVersion,
        $ConfigurationTargetVersion,
        $TargetVersion,
        [switch] $ApplyUpdate
    )

    if ($ConfigurationCurrentVersion.SolutionMetadata.JSonVersion -ne $ConfigurationTargetVersion.SolutionMetadata.JSonVersion)
    {
        Write-LogMessage "The version of the target configuration file $($ConfigurationTargetVersion.SolutionMetadata.JSonVersion) is not the same as the version of the script $($ConfigurationCurrentVersion.SolutionMetadata.JSonVersion). Configuration file need to be updated." -Level Warning
    
        $ConfigurationCurrentVersion.SolutionMetadata = $ConfigurationTargetVersion.SolutionMetadata
        $Script:MissingParameters = $true
    }

    Write-Host "`nConfiguration file will be verified to see if missing parameter has to be added." -ForegroundColor Green
    $Script:ParameterErrorList = CheckRecursive -JsonSegment $ConfigurationTargetVersion -JsonTestSegment $ConfigurationCurrentVersion -TestType $TargetVersion -ApplyUpdate:$ApplyUpdate

    if ($null -ne $ParameterErrorList -and $ParameterErrorList.ErrorCount -gt 0)
    {
        Write-LogMessage "The following parameters are missing or have changed :"
        foreach ($ParameterError in $Script:ParameterErrorList.TotalList)
        {
            Write-LogMessage "    $($ParameterError.ErrorMessage)"
        }

        if (-not $ConfigFileReadOnly) {Write-LogMessage "The configuration file will be updated with the missing parameters."}
        else {Write-LogMessage "The configuration file will not be updated because it is read only."}
        $Script:MissingParameters = $true
    }
}

function Get-ConfigurationTargetVersionJson
{
    Write-LogMessage "Get the configuration file from the repository."
    $VersionTracking = Get-VersionTrackingFromOnline

    Write-LogMessage "The latest version of the Script file is $($VersionTracking.LatestVersion)."

    $TargetVersion = $VersionTracking.VersionHistory | Where-Object { $_.Version -eq $VersionTracking.LatestVersion }
    $SourcePath = "$($VersionTracking.ESICollectorRawRepository)/$($TargetVersion.VersionFileName)"
    
     # Download the file
     try {
        $DownloadedFile = Invoke-ESIWebRequest -Uri $SourcePath
    }
    catch {
        Write-LogMessage "Unable to download the file $SourcePath. Exception $($_.Exception); Fatal Error" -Level Error
        return
    }

    Write-LogMessage "Extracting the configuration file from the downloaded zip file"
    $script:ConfigurationTargetVersion = $null
    
    try {
        $DownloadedFile = [System.IO.MemoryStream]::new($DownloadedFile)
        $ZipFile = [System.IO.Compression.ZipArchive]::new($DownloadedFile)
        $files = $ZipFile.Entries | Where-Object { $_.Name -eq "CollectExchSecConfiguration.json" }
        $files | ForEach-Object {
            $File = $_
            $FileContent = $File.Open()
            if ("CollectExchSecConfiguration.json" -eq $File.Name) {
                Write-LogMessage "Processing CollectExchSecConfiguration.json file"
                if ($DownloadOnly) {
                    if (-not $WhatIf) { $FileContent.CopyTo([System.IO.File]::Create("$TargetPath\CollectExchSecConfiguration-ForNewVersion.json")) }
                    else { Write-LogMessage "WhatIf mode, no file will be created - Tested file : $TargetPath\CollectExchSecConfiguration-ForNewVersion.json" }
                }
                else {
                    Write-LogMessage "Write Extracted file in StrreamReader"
                    # extract filestream to string
                    $StreamReader = [System.IO.StreamReader]::new($FileContent)
                    $script:ConfigurationTargetVersion = $StreamReader.ReadToEnd()
                    $StreamReader.Close()
                    
                    Write-LogMessage "Convert Json to Object"
                    $script:ConfigurationTargetVersion = $script:ConfigurationTargetVersion | ConvertFrom-Json
                }
            }
            $FileContent.Close()
        }

        $ZipFile.Dispose()
    }
    catch {
        Write-LogMessage "Unable to extract the PowerShell script from the downloaded zip file. Exception $($_.Exception); Fatal Error" -Level Error
        return
    }
}

function Save-ConfigurationTargetVersion
{
    Param(
        $ConfigurationTargetVersion
    )

    $ConfigInJSON = $ConfigurationTargetVersion | ConvertTo-Json

    if ($global:isRunbook) {
        if (-not $WhatIf) { Set-AutomationVariable -Name "GlobalConfiguration" -Value $ConfigInJSON.ToString() }
        else { Write-LogMessage "WhatIf mode, Simulate Set GlobalConfiguration with New Json" }

    }
    else {
        if (-not $WhatIf) { $ConfigInJSON | Out-File "$TargetPath\Config\CollectExchSecConfiguration.json" -Encoding UTF8 }
        else { Write-LogMessage "WhatIf mode, no file will be created - Tested file : $TargetPath\Config\CollectExchSecConfiguration.json" }
    }
}

if (-not $Global:isRunbook )
{
    $scriptFolder = Split-Path -Parent $MyInvocation.MyCommand.Definition
    $Script:scriptFolder = $scriptFolder
    $ScriptLogPath = $scriptFolder + '\Logs'

    Push-Location ($scriptFolder);
    if (! (Test-Path $ScriptLogPath)) { mkdir $ScriptLogPath }

    $ScriptLogFile = "$ScriptLogPath\Updater-$DateSuffixForFile.log"
    Start-Transcript -Path $ScriptLogFile

    CleanFiles -ScriptLogPath $ScriptLogPath -ClearFilesOlderThan $ClearFilesOlderThan
    if ([string]::IsNullOrEmpty($TargetPath)) {
        $TargetPath = $scriptFolder
    }

    if (-not $DownloadOnly) { Start-ScriptBackup -TargetPath $TargetPath -ClearFilesOlderThan $ClearFilesOlderThan }
}

#region Verify Parameters

    if ($FromInternet -and $OfflineUpdate) {
        Write-LogMessage "You can't use FromInternet and OfflineUpdate at the same time" -Level Error
        exit
    }

    if ($Global:isRunbook) {
        if ($OfflineUpdate) {
            Write-LogMessage "OfflineUpdate is not supported in Azure Automation" -Level Error
            exit
        }
        if ($DownloadOnly) {
            Write-LogMessage "DownloadOnly is not supported in Azure Automation" -Level Error
            exit
        }
        if ($IncludeAddOnsUpdate) {
            Write-LogMessage "Update AddOns is not supported in Azure Automation" -Level Error
            exit
        }
    }

    if ($true -eq $FromInternet -and $true -eq $OfflineUpdate) {
        Write-LogMessage "You must use FromInternet or OfflineUpdate switch" -Level Error
        exit
    }

#endregion

# Connect to Automation Account to modify a Runbook
if ($Global:isRunbook) {
  
    # Get the Runbook Start-ESICollector
    #$script:RunbookContent = Get-AzAutomationRunbook -ResourceGroupName $script:resourceGroup -AutomationAccountName $script:automationAccountName -Name "Start-ESICollector"
    
    $script:RunbookContent = Get-AzureAutomationRunbook -Runbook "Start-ESICollector"

    if ($null -eq $RunbookContent) {
        Write-LogMessage "Unable to get the Runbook Start-ESICollector. Fatal Error" -Level Error
        exit
    }
}


Get-CurrentVersionOfScript -TargetPath $TargetPath

if ($FromInternet) {
    if (-not $UpdateAddonsOnly) { Update-ScriptFromInternet -TargetPath $TargetPath -CurrentVersion $CurrentVersion -SpecificTargetVersion $SpecificTargetVersion -ForceUpdate:$ForceUpdate -DownloadOnly:$DownloadOnly -InternalSpecificVersion $InternalSpecificVersion -InternalVersionCurentFile $InternalVersionCurentFile }
    if ($IncludeAddOnsUpdate) 
    { 
        if (-not $DownloadOnly)
        {
            Update-AddonsFromInternetRepository -Beta:$BetaVersion -TargetPath $TargetPath

            foreach ($Category in $Categories) {
                Update-AddonsFromInternetRepository -Beta:$BetaVersion -TargetPath $TargetPath -Category $Category
            }
        }
        else
        {
            Write-LogMessage "IncludeUpdateConfiguration is not supported with DownloadOnly switch" -Level Error

            Start-AddonsDownload -SourcePath $SourcePath -TargetPath $TargetPath -Beta:$BetaVersion

            foreach ($Category in $Categories) {
                Start-AddonsDownload -SourcePath $SourcePath -TargetPath $TargetPath -Category $Category -Beta:$BetaVersion
            }
        }
    }

    if (-not $IgnoreConfigurationFile)
    {
        if ($null -eq $Script:ConfigurationTargetVersion) 
        { 
            Get-ConfigurationTargetVersionJson
        }
        
        try {
            if ($Global:isRunbook) {
                $ConfigurationCurrentVersion = Get-AutomationVariable -Name "GlobalConfiguration" -ErrorAction Stop | ConvertFrom-Json
            }
            else {
                $ConfigurationCurrentVersion = Get-Content "$TargetPath\Config\CollectExchSecConfiguration.json" -Raw | ConvertFrom-Json
            }

            CheckConfigurationFile -ConfigurationTargetVersion $script:ConfigurationTargetVersion -ConfigurationCurrentVersion $ConfigurationCurrentVersion -TargetVersion "$($TargetVersion.Version)" -ApplyUpdate:(-not $ConfigFileReadOnly)
        
            if ($Script:MissingParameters) 
            { 
                if (-not $ConfigFileReadOnly) { Save-ConfigurationTargetVersion -ConfigurationTargetVersion $ConfigurationCurrentVersion }
                $Script:EndMessageLevel = "Warning"; $Script:EndMessage += "Attention, missing parameters, see above." 
            }
    
      }
        catch {
                Write-LogMessage "Unable to load the CollectExchSecConfiguration.json file from the target directory or CollectExchSecConfiguration-ForNewVersion.json from source directory or compare it with target version. Exception $($_.Exception); Configuration not validated but Script updated." -Level Error
            }
    }
}

if ($OfflineUpdate)
{
    if (-not $UpdateAddonsOnly) { Update-ScriptOfflineMode -SourcePath $SourcePath -TargetPath $TargetPath -CurrentVersion $CurrentVersion -SpecificTargetVersion $SpecificTargetVersion -ForceUpdate:$ForceUpdate -InternalSpecificVersion $InternalSpecificVersion -InternalVersionCurentFile $InternalVersionCurentFile }
    if ($IncludeAddOnsUpdate) 
    { 
        Update-AddonsOfflineMode -SourcePath $SourcePath -TargetPath $TargetPath

        foreach ($Category in $Categories) {
            Update-AddonsOfflineMode -SourcePath $SourcePath -TargetPath $TargetPath -Category $Category
        }
    }

    if (-not $IgnoreConfigurationFile)
    {
        try {
            $ConfigurationTargetVersion = Get-Content -Path "$SourcePath\CollectExchSecConfiguration-ForNewVersion.json" | ConvertFrom-Json
    
            $ConfigurationCurrentVersion = Get-Content "$TargetPath\Config\CollectExchSecConfiguration.json" -Raw | ConvertFrom-Json
    
            CheckConfigurationFile -ConfigurationTargetVersion $ConfigurationTargetVersion -ConfigurationCurrentVersion $ConfigurationCurrentVersion -TargetVersion "$($TargetVersion.Version)" -ApplyUpdate:(-not $ConfigFileReadOnly)

            if (-not [string]::IsNullOrEmpty($script:TargetMove)) 
            { 
                if (-not $WhatIf) { Move-Item -Path "$SourcePath\CollectExchSecConfiguration-ForNewVersion.json" -Destination "$script:TargetMove\CollectExchSecConfiguration-ForNewVersion.json" -Force }
                else { Write-LogMessage "WhatIf mode, no file will be moved - Tested file : $SourcePath\CollectExchSecConfiguration-ForNewVersion.json" }
            }

            if ($Script:MissingParameters) 
            { 
                if (-not $ConfigFileReadOnly) { Save-ConfigurationTargetVersion -ConfigurationTargetVersion $ConfigurationCurrentVersion }
                $Script:EndMessageLevel = "Warning"; $Script:EndMessage += "Attention, missing parameters, see above." 
            }
    
      }
        catch {
                Write-LogMessage "Unable to load the CollectExchSecConfiguration.json file from the target directory or CollectExchSecConfiguration-ForNewVersion.json from source directory or compare it with target version. Exception $($_.Exception); Configuration not validated but Script updated." -Level Error
            }
    }
}

if ($Script:EndMessage.count -gt 0)
{
    Write-LogMessage "The following messages were generated during the execution of the script :"
    foreach ($Message in $Script:EndMessage)
    {
        Write-LogMessage "    $($Message)" -Level $Script:EndMessageLevel
    }
}

Write-LogMessage -Message ("Updater finished")
Write-Output "`n**************** LOGS **********************"
Write-Output (Get-UDSLogs)
Write-Output "**************** END LOGS **********************`n"

if (-not $Global:isRunbook )
{
    Stop-Transcript
}